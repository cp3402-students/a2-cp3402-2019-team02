# WordPress MySQL database migration
#
# Generated: Friday 3. May 2019 03:24 UTC
# Hostname: localhost
# Database: `team2`
# URL: //localhost:8888
# Path: /Users/danielarcher/Sites/www
# Tables: wp_commentmeta, wp_comments, wp_links, wp_options, wp_postmeta, wp_posts, wp_term_relationships, wp_term_taxonomy, wp_termmeta, wp_terms, wp_usermeta, wp_users
# Table Prefix: wp_
# Post Types: revision, attachment, customize_changeset, nav_menu_item, page, post
# Protocol: http
# Multisite: false
# Subsite Export: false
# --------------------------------------------------------

/*!40101 SET NAMES utf8 */;

SET sql_mode='NO_AUTO_VALUE_ON_ZERO';



#
# Delete any existing table `wp_commentmeta`
#

DROP TABLE IF EXISTS `wp_commentmeta`;


#
# Table structure of table `wp_commentmeta`
#

CREATE TABLE `wp_commentmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`meta_id`),
  KEY `comment_id` (`comment_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_commentmeta`
#

#
# End of data contents of table `wp_commentmeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_comments`
#

DROP TABLE IF EXISTS `wp_comments`;


#
# Table structure of table `wp_comments`
#

CREATE TABLE `wp_comments` (
  `comment_ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_post_ID` bigint(20) unsigned NOT NULL DEFAULT '0',
  `comment_author` tinytext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `comment_author_email` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_author_url` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_author_IP` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_content` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `comment_karma` int(11) NOT NULL DEFAULT '0',
  `comment_approved` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '1',
  `comment_agent` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_type` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`comment_ID`),
  KEY `comment_post_ID` (`comment_post_ID`),
  KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`),
  KEY `comment_date_gmt` (`comment_date_gmt`),
  KEY `comment_parent` (`comment_parent`),
  KEY `comment_author_email` (`comment_author_email`(10))
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_comments`
#
INSERT INTO `wp_comments` ( `comment_ID`, `comment_post_ID`, `comment_author`, `comment_author_email`, `comment_author_url`, `comment_author_IP`, `comment_date`, `comment_date_gmt`, `comment_content`, `comment_karma`, `comment_approved`, `comment_agent`, `comment_type`, `comment_parent`, `user_id`) VALUES
(1, 1, 'A WordPress Commenter', 'wapuu@wordpress.example', 'https://wordpress.org/', '', '2019-04-22 00:07:39', '2019-04-22 00:07:39', 'Hi, this is a comment.\nTo get started with moderating, editing, and deleting comments, please visit the Comments screen in the dashboard.\nCommenter avatars come from <a href="https://gravatar.com">Gravatar</a>.', 0, '1', '', '', 0, 0) ;

#
# End of data contents of table `wp_comments`
# --------------------------------------------------------



#
# Delete any existing table `wp_links`
#

DROP TABLE IF EXISTS `wp_links`;


#
# Table structure of table `wp_links`
#

CREATE TABLE `wp_links` (
  `link_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `link_url` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_name` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_image` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_target` varchar(25) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_description` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_visible` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'Y',
  `link_owner` bigint(20) unsigned NOT NULL DEFAULT '1',
  `link_rating` int(11) NOT NULL DEFAULT '0',
  `link_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `link_rel` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_notes` mediumtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `link_rss` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`link_id`),
  KEY `link_visible` (`link_visible`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_links`
#

#
# End of data contents of table `wp_links`
# --------------------------------------------------------



#
# Delete any existing table `wp_options`
#

DROP TABLE IF EXISTS `wp_options`;


#
# Table structure of table `wp_options`
#

CREATE TABLE `wp_options` (
  `option_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `option_name` varchar(191) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `option_value` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `autoload` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'yes',
  PRIMARY KEY (`option_id`),
  UNIQUE KEY `option_name` (`option_name`)
) ENGINE=InnoDB AUTO_INCREMENT=373 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_options`
#
INSERT INTO `wp_options` ( `option_id`, `option_name`, `option_value`, `autoload`) VALUES
(1, 'siteurl', 'http://localhost:8888', 'yes'),
(2, 'home', 'http://localhost:8888', 'yes'),
(3, 'blogname', '', 'yes'),
(4, 'blogdescription', '', 'yes'),
(5, 'users_can_register', '0', 'yes'),
(6, 'admin_email', 'jc313927@gmail.com', 'yes'),
(7, 'start_of_week', '1', 'yes'),
(8, 'use_balanceTags', '0', 'yes'),
(9, 'use_smilies', '1', 'yes'),
(10, 'require_name_email', '1', 'yes'),
(11, 'comments_notify', '1', 'yes'),
(12, 'posts_per_rss', '10', 'yes'),
(13, 'rss_use_excerpt', '0', 'yes'),
(14, 'mailserver_url', 'mail.example.com', 'yes'),
(15, 'mailserver_login', 'login@example.com', 'yes'),
(16, 'mailserver_pass', 'password', 'yes'),
(17, 'mailserver_port', '110', 'yes'),
(18, 'default_category', '1', 'yes'),
(19, 'default_comment_status', 'open', 'yes'),
(20, 'default_ping_status', 'open', 'yes'),
(21, 'default_pingback_flag', '1', 'yes'),
(22, 'posts_per_page', '10', 'yes'),
(23, 'date_format', 'F j, Y', 'yes'),
(24, 'time_format', 'g:i a', 'yes'),
(25, 'links_updated_date_format', 'F j, Y g:i a', 'yes'),
(26, 'comment_moderation', '0', 'yes'),
(27, 'moderation_notify', '1', 'yes'),
(28, 'permalink_structure', '/index.php/%year%/%monthnum%/%day%/%postname%/', 'yes'),
(29, 'rewrite_rules', 'a:90:{s:11:"^wp-json/?$";s:22:"index.php?rest_route=/";s:14:"^wp-json/(.*)?";s:33:"index.php?rest_route=/$matches[1]";s:21:"^index.php/wp-json/?$";s:22:"index.php?rest_route=/";s:24:"^index.php/wp-json/(.*)?";s:33:"index.php?rest_route=/$matches[1]";s:57:"index.php/category/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:52:"index.php/category/(.+?)/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:33:"index.php/category/(.+?)/embed/?$";s:46:"index.php?category_name=$matches[1]&embed=true";s:45:"index.php/category/(.+?)/page/?([0-9]{1,})/?$";s:53:"index.php?category_name=$matches[1]&paged=$matches[2]";s:27:"index.php/category/(.+?)/?$";s:35:"index.php?category_name=$matches[1]";s:54:"index.php/tag/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:49:"index.php/tag/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:30:"index.php/tag/([^/]+)/embed/?$";s:36:"index.php?tag=$matches[1]&embed=true";s:42:"index.php/tag/([^/]+)/page/?([0-9]{1,})/?$";s:43:"index.php?tag=$matches[1]&paged=$matches[2]";s:24:"index.php/tag/([^/]+)/?$";s:25:"index.php?tag=$matches[1]";s:55:"index.php/type/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_format=$matches[1]&feed=$matches[2]";s:50:"index.php/type/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_format=$matches[1]&feed=$matches[2]";s:31:"index.php/type/([^/]+)/embed/?$";s:44:"index.php?post_format=$matches[1]&embed=true";s:43:"index.php/type/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?post_format=$matches[1]&paged=$matches[2]";s:25:"index.php/type/([^/]+)/?$";s:33:"index.php?post_format=$matches[1]";s:48:".*wp-(atom|rdf|rss|rss2|feed|commentsrss2)\\.php$";s:18:"index.php?feed=old";s:20:".*wp-app\\.php(/.*)?$";s:19:"index.php?error=403";s:18:".*wp-register.php$";s:23:"index.php?register=true";s:42:"index.php/feed/(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:37:"index.php/(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:18:"index.php/embed/?$";s:21:"index.php?&embed=true";s:30:"index.php/page/?([0-9]{1,})/?$";s:28:"index.php?&paged=$matches[1]";s:37:"index.php/comment-page-([0-9]{1,})/?$";s:39:"index.php?&page_id=76&cpage=$matches[1]";s:51:"index.php/comments/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:46:"index.php/comments/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:27:"index.php/comments/embed/?$";s:21:"index.php?&embed=true";s:54:"index.php/search/(.+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:49:"index.php/search/(.+)/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:30:"index.php/search/(.+)/embed/?$";s:34:"index.php?s=$matches[1]&embed=true";s:42:"index.php/search/(.+)/page/?([0-9]{1,})/?$";s:41:"index.php?s=$matches[1]&paged=$matches[2]";s:24:"index.php/search/(.+)/?$";s:23:"index.php?s=$matches[1]";s:57:"index.php/author/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:52:"index.php/author/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:33:"index.php/author/([^/]+)/embed/?$";s:44:"index.php?author_name=$matches[1]&embed=true";s:45:"index.php/author/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?author_name=$matches[1]&paged=$matches[2]";s:27:"index.php/author/([^/]+)/?$";s:33:"index.php?author_name=$matches[1]";s:79:"index.php/([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:74:"index.php/([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:55:"index.php/([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/embed/?$";s:74:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&embed=true";s:67:"index.php/([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:81:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&paged=$matches[4]";s:49:"index.php/([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/?$";s:63:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]";s:66:"index.php/([0-9]{4})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:61:"index.php/([0-9]{4})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:42:"index.php/([0-9]{4})/([0-9]{1,2})/embed/?$";s:58:"index.php?year=$matches[1]&monthnum=$matches[2]&embed=true";s:54:"index.php/([0-9]{4})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:65:"index.php?year=$matches[1]&monthnum=$matches[2]&paged=$matches[3]";s:36:"index.php/([0-9]{4})/([0-9]{1,2})/?$";s:47:"index.php?year=$matches[1]&monthnum=$matches[2]";s:53:"index.php/([0-9]{4})/feed/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:48:"index.php/([0-9]{4})/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:29:"index.php/([0-9]{4})/embed/?$";s:37:"index.php?year=$matches[1]&embed=true";s:41:"index.php/([0-9]{4})/page/?([0-9]{1,})/?$";s:44:"index.php?year=$matches[1]&paged=$matches[2]";s:23:"index.php/([0-9]{4})/?$";s:26:"index.php?year=$matches[1]";s:68:"index.php/[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:78:"index.php/[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:98:"index.php/[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:93:"index.php/[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:93:"index.php/[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:74:"index.php/[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:63:"index.php/([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/embed/?$";s:91:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&embed=true";s:67:"index.php/([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/trackback/?$";s:85:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&tb=1";s:87:"index.php/([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:97:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&feed=$matches[5]";s:82:"index.php/([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:97:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&feed=$matches[5]";s:75:"index.php/([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/page/?([0-9]{1,})/?$";s:98:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&paged=$matches[5]";s:82:"index.php/([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/comment-page-([0-9]{1,})/?$";s:98:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&cpage=$matches[5]";s:71:"index.php/([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)(?:/([0-9]+))?/?$";s:97:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&page=$matches[5]";s:57:"index.php/[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:67:"index.php/[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:87:"index.php/[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:82:"index.php/[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:82:"index.php/[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:63:"index.php/[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:74:"index.php/([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/comment-page-([0-9]{1,})/?$";s:81:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&cpage=$matches[4]";s:61:"index.php/([0-9]{4})/([0-9]{1,2})/comment-page-([0-9]{1,})/?$";s:65:"index.php?year=$matches[1]&monthnum=$matches[2]&cpage=$matches[3]";s:48:"index.php/([0-9]{4})/comment-page-([0-9]{1,})/?$";s:44:"index.php?year=$matches[1]&cpage=$matches[2]";s:37:"index.php/.?.+?/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:47:"index.php/.?.+?/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:67:"index.php/.?.+?/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:62:"index.php/.?.+?/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:62:"index.php/.?.+?/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:43:"index.php/.?.+?/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:26:"index.php/(.?.+?)/embed/?$";s:41:"index.php?pagename=$matches[1]&embed=true";s:30:"index.php/(.?.+?)/trackback/?$";s:35:"index.php?pagename=$matches[1]&tb=1";s:50:"index.php/(.?.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:45:"index.php/(.?.+?)/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:38:"index.php/(.?.+?)/page/?([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&paged=$matches[2]";s:45:"index.php/(.?.+?)/comment-page-([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&cpage=$matches[2]";s:34:"index.php/(.?.+?)(?:/([0-9]+))?/?$";s:47:"index.php?pagename=$matches[1]&page=$matches[2]";}', 'yes'),
(30, 'hack_file', '0', 'yes'),
(31, 'blog_charset', 'UTF-8', 'yes'),
(32, 'moderation_keys', '', 'no'),
(33, 'active_plugins', 'a:2:{i:0;s:45:"gallery-custom-links/gallery_custom_links.php";i:1;s:31:"wp-migrate-db/wp-migrate-db.php";}', 'yes'),
(34, 'category_base', '', 'yes'),
(35, 'ping_sites', 'http://rpc.pingomatic.com/', 'yes'),
(36, 'comment_max_links', '2', 'yes'),
(37, 'gmt_offset', '10', 'yes'),
(38, 'default_email_category', '1', 'yes'),
(39, 'recently_edited', 'a:5:{i:0;s:106:"/Users/danielarcher/Sites/www/wp-content/themes/twentyseventeen/template-parts/page/content-front-page.php";i:1;s:102:"/Users/danielarcher/Sites/www/wp-content/themes/twentyseventeen/template-parts/header/header-image.php";i:2;s:77:"/Users/danielarcher/Sites/www/wp-content/themes/twentyseventeen/functions.php";i:3;s:73:"/Users/danielarcher/Sites/www/wp-content/themes/twentyseventeen/index.php";i:4;s:78:"/Users/danielarcher/Sites/www/wp-content/themes/twentyseventeen/front-page.php";}', 'no'),
(40, 'template', 'team02', 'yes'),
(41, 'stylesheet', 'team02', 'yes'),
(42, 'comment_whitelist', '1', 'yes'),
(43, 'blacklist_keys', '', 'no'),
(44, 'comment_registration', '0', 'yes'),
(45, 'html_type', 'text/html', 'yes'),
(46, 'use_trackback', '0', 'yes'),
(47, 'default_role', 'subscriber', 'yes'),
(48, 'db_version', '44719', 'yes'),
(49, 'uploads_use_yearmonth_folders', '1', 'yes'),
(50, 'upload_path', '', 'yes'),
(51, 'blog_public', '1', 'yes'),
(52, 'default_link_category', '2', 'yes'),
(53, 'show_on_front', 'page', 'yes'),
(54, 'tag_base', '', 'yes'),
(55, 'show_avatars', '1', 'yes'),
(56, 'avatar_rating', 'G', 'yes'),
(57, 'upload_url_path', '', 'yes'),
(58, 'thumbnail_size_w', '150', 'yes'),
(59, 'thumbnail_size_h', '150', 'yes'),
(60, 'thumbnail_crop', '1', 'yes'),
(61, 'medium_size_w', '300', 'yes'),
(62, 'medium_size_h', '300', 'yes'),
(63, 'avatar_default', 'mystery', 'yes'),
(64, 'large_size_w', '1024', 'yes'),
(65, 'large_size_h', '1024', 'yes'),
(66, 'image_default_link_type', 'none', 'yes'),
(67, 'image_default_size', '', 'yes'),
(68, 'image_default_align', '', 'yes'),
(69, 'close_comments_for_old_posts', '0', 'yes'),
(70, 'close_comments_days_old', '14', 'yes'),
(71, 'thread_comments', '1', 'yes'),
(72, 'thread_comments_depth', '5', 'yes'),
(73, 'page_comments', '0', 'yes'),
(74, 'comments_per_page', '50', 'yes'),
(75, 'default_comments_page', 'newest', 'yes'),
(76, 'comment_order', 'asc', 'yes'),
(77, 'sticky_posts', 'a:0:{}', 'yes'),
(78, 'widget_categories', 'a:2:{i:2;a:4:{s:5:"title";s:0:"";s:5:"count";i:0;s:12:"hierarchical";i:0;s:8:"dropdown";i:0;}s:12:"_multiwidget";i:1;}', 'yes'),
(79, 'widget_text', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes'),
(80, 'widget_rss', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes'),
(81, 'uninstall_plugins', 'a:0:{}', 'no'),
(82, 'timezone_string', '', 'yes'),
(83, 'page_for_posts', '0', 'yes'),
(84, 'page_on_front', '76', 'yes'),
(85, 'default_post_format', '0', 'yes'),
(86, 'link_manager_enabled', '0', 'yes'),
(87, 'finished_splitting_shared_terms', '1', 'yes'),
(88, 'site_icon', '0', 'yes'),
(89, 'medium_large_size_w', '768', 'yes'),
(90, 'medium_large_size_h', '0', 'yes'),
(91, 'wp_page_for_privacy_policy', '3', 'yes'),
(92, 'show_comments_cookies_opt_in', '1', 'yes'),
(93, 'initial_db_version', '44719', 'yes'),
(94, 'wp_user_roles', 'a:5:{s:13:"administrator";a:2:{s:4:"name";s:13:"Administrator";s:12:"capabilities";a:61:{s:13:"switch_themes";b:1;s:11:"edit_themes";b:1;s:16:"activate_plugins";b:1;s:12:"edit_plugins";b:1;s:10:"edit_users";b:1;s:10:"edit_files";b:1;s:14:"manage_options";b:1;s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:6:"import";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:8:"level_10";b:1;s:7:"level_9";b:1;s:7:"level_8";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;s:12:"delete_users";b:1;s:12:"create_users";b:1;s:17:"unfiltered_upload";b:1;s:14:"edit_dashboard";b:1;s:14:"update_plugins";b:1;s:14:"delete_plugins";b:1;s:15:"install_plugins";b:1;s:13:"update_themes";b:1;s:14:"install_themes";b:1;s:11:"update_core";b:1;s:10:"list_users";b:1;s:12:"remove_users";b:1;s:13:"promote_users";b:1;s:18:"edit_theme_options";b:1;s:13:"delete_themes";b:1;s:6:"export";b:1;}}s:6:"editor";a:2:{s:4:"name";s:6:"Editor";s:12:"capabilities";a:34:{s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;}}s:6:"author";a:2:{s:4:"name";s:6:"Author";s:12:"capabilities";a:10:{s:12:"upload_files";b:1;s:10:"edit_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:4:"read";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;s:22:"delete_published_posts";b:1;}}s:11:"contributor";a:2:{s:4:"name";s:11:"Contributor";s:12:"capabilities";a:5:{s:10:"edit_posts";b:1;s:4:"read";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;}}s:10:"subscriber";a:2:{s:4:"name";s:10:"Subscriber";s:12:"capabilities";a:2:{s:4:"read";b:1;s:7:"level_0";b:1;}}}', 'yes'),
(95, 'fresh_site', '0', 'yes'),
(96, 'widget_search', 'a:2:{i:2;a:1:{s:5:"title";s:0:"";}s:12:"_multiwidget";i:1;}', 'yes'),
(97, 'widget_recent-posts', 'a:2:{i:2;a:2:{s:5:"title";s:0:"";s:6:"number";i:5;}s:12:"_multiwidget";i:1;}', 'yes'),
(98, 'widget_recent-comments', 'a:2:{i:2;a:2:{s:5:"title";s:0:"";s:6:"number";i:5;}s:12:"_multiwidget";i:1;}', 'yes'),
(99, 'widget_archives', 'a:2:{i:2;a:3:{s:5:"title";s:0:"";s:5:"count";i:0;s:8:"dropdown";i:0;}s:12:"_multiwidget";i:1;}', 'yes'),
(100, 'widget_meta', 'a:2:{i:2;a:1:{s:5:"title";s:0:"";}s:12:"_multiwidget";i:1;}', 'yes') ;
INSERT INTO `wp_options` ( `option_id`, `option_name`, `option_value`, `autoload`) VALUES
(101, 'sidebars_widgets', 'a:3:{s:19:"wp_inactive_widgets";a:0:{}s:9:"sidebar-1";a:0:{}s:13:"array_version";i:3;}', 'yes'),
(102, 'widget_pages', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(103, 'widget_calendar', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(104, 'widget_media_audio', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(105, 'widget_media_image', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(106, 'widget_media_gallery', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(107, 'widget_media_video', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(108, 'widget_tag_cloud', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(109, 'widget_nav_menu', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(110, 'widget_custom_html', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(111, 'cron', 'a:5:{i:1556856459;a:1:{s:34:"wp_privacy_delete_old_export_files";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:6:"hourly";s:4:"args";a:0:{}s:8:"interval";i:3600;}}}i:1556885259;a:3:{s:16:"wp_version_check";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:17:"wp_update_plugins";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:16:"wp_update_themes";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1556929035;a:2:{s:19:"wp_scheduled_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}s:25:"delete_expired_transients";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1556929036;a:1:{s:30:"wp_scheduled_auto_draft_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}s:7:"version";i:2;}', 'yes'),
(112, 'theme_mods_twentynineteen', 'a:2:{s:18:"custom_css_post_id";i:-1;s:16:"sidebars_widgets";a:2:{s:4:"time";i:1555891660;s:4:"data";a:2:{s:19:"wp_inactive_widgets";a:0:{}s:9:"sidebar-1";a:6:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:12:"categories-2";i:5;s:6:"meta-2";}}}}', 'yes'),
(117, 'current_theme', 'team02', 'yes'),
(118, 'theme_switched', '', 'yes'),
(122, 'theme_mods_twentyseventeen', 'a:3:{s:18:"nav_menu_locations";a:0:{}s:18:"custom_css_post_id";i:-1;s:16:"sidebars_widgets";a:2:{s:4:"time";i:1556596676;s:4:"data";a:4:{s:19:"wp_inactive_widgets";a:0:{}s:9:"sidebar-1";a:6:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:12:"categories-2";i:5;s:6:"meta-2";}s:9:"sidebar-2";a:0:{}s:9:"sidebar-3";a:0:{}}}}', 'yes'),
(129, 'can_compress_scripts', '0', 'no'),
(144, 'WPLANG', 'en_AU', 'yes'),
(145, 'new_admin_email', 'jc313927@gmail.com', 'yes'),
(207, 'recently_activated', 'a:0:{}', 'yes'),
(212, 'wpmdb_usage', 'a:2:{s:6:"action";s:8:"savefile";s:4:"time";i:1556853862;}', 'no'),
(273, 'theme_mods_team2_theme', 'a:7:{s:18:"custom_css_post_id";i:-1;s:18:"nav_menu_locations";a:1:{s:6:"menu-1";i:2;}s:16:"background_color";s:6:"ffffff";s:12:"header_image";s:68:"http://localhost:8888/wp-content/uploads/2019/04/cropped-testcat.jpg";s:17:"header_image_data";O:8:"stdClass":5:{s:13:"attachment_id";i:30;s:3:"url";s:68:"http://localhost:8888/wp-content/uploads/2019/04/cropped-testcat.jpg";s:13:"thumbnail_url";s:68:"http://localhost:8888/wp-content/uploads/2019/04/cropped-testcat.jpg";s:6:"height";i:249;s:5:"width";i:1000;}s:11:"custom_logo";s:0:"";s:16:"sidebars_widgets";a:2:{s:4:"time";i:1556774609;s:4:"data";a:2:{s:19:"wp_inactive_widgets";a:0:{}s:9:"sidebar-1";a:6:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:12:"categories-2";i:5;s:6:"meta-2";}}}}', 'yes'),
(309, 'nav_menu_options', 'a:1:{s:8:"auto_add";a:0:{}}', 'yes'),
(313, 'category_children', 'a:0:{}', 'yes'),
(340, 'theme_mods_team02', 'a:5:{i:0;b:0;s:18:"nav_menu_locations";a:1:{s:6:"menu-1";i:2;}s:18:"custom_css_post_id";i:-1;s:12:"header_image";s:71:"http://localhost:8888/wp-content/uploads/2019/05/cropped-COFFEECAN2.png";s:17:"header_image_data";O:8:"stdClass":5:{s:13:"attachment_id";i:54;s:3:"url";s:71:"http://localhost:8888/wp-content/uploads/2019/05/cropped-COFFEECAN2.png";s:13:"thumbnail_url";s:71:"http://localhost:8888/wp-content/uploads/2019/05/cropped-COFFEECAN2.png";s:6:"height";i:240;s:5:"width";i:240;}}', 'yes') ;

#
# End of data contents of table `wp_options`
# --------------------------------------------------------



#
# Delete any existing table `wp_postmeta`
#

DROP TABLE IF EXISTS `wp_postmeta`;


#
# Table structure of table `wp_postmeta`
#

CREATE TABLE `wp_postmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`meta_id`),
  KEY `post_id` (`post_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=291 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_postmeta`
#
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(1, 2, '_wp_page_template', 'default'),
(2, 3, '_wp_page_template', 'default'),
(3, 5, '_wp_trash_meta_status', 'auto-draft'),
(4, 5, '_wp_trash_meta_time', '1555893625'),
(5, 5, '_wp_desired_post_slug', ''),
(12, 11, '_wp_attached_file', '2019/04/testcat.jpg'),
(13, 11, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:557;s:6:"height";i:573;s:4:"file";s:19:"2019/04/testcat.jpg";s:5:"sizes";a:3:{s:9:"thumbnail";a:4:{s:4:"file";s:19:"testcat-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:19:"testcat-292x300.jpg";s:5:"width";i:292;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:32:"twentyseventeen-thumbnail-avatar";a:4:{s:4:"file";s:19:"testcat-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(14, 12, '_edit_lock', '1556013126:3'),
(17, 12, '_thumbnail_id', '11'),
(20, 15, '_wp_trash_meta_status', 'publish'),
(21, 15, '_wp_trash_meta_time', '1555996991'),
(22, 16, '_wp_trash_meta_status', 'publish'),
(23, 16, '_wp_trash_meta_time', '1555997587'),
(24, 17, '_wp_trash_meta_status', 'publish'),
(25, 17, '_wp_trash_meta_time', '1555997925'),
(30, 20, '_edit_lock', '1556014035:3'),
(31, 23, '_menu_item_type', 'custom'),
(32, 23, '_menu_item_menu_item_parent', '0'),
(33, 23, '_menu_item_object_id', '23'),
(34, 23, '_menu_item_object', 'custom'),
(35, 23, '_menu_item_target', ''),
(36, 23, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(37, 23, '_menu_item_xfn', ''),
(38, 23, '_menu_item_url', 'http://localhost:8888/'),
(39, 23, '_menu_item_orphaned', '1556596970'),
(40, 24, '_menu_item_type', 'post_type'),
(41, 24, '_menu_item_menu_item_parent', '0'),
(42, 24, '_menu_item_object_id', '2'),
(43, 24, '_menu_item_object', 'page'),
(44, 24, '_menu_item_target', ''),
(45, 24, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(46, 24, '_menu_item_xfn', ''),
(47, 24, '_menu_item_url', ''),
(48, 24, '_menu_item_orphaned', '1556596970'),
(50, 26, '_menu_item_type', 'custom'),
(51, 26, '_menu_item_menu_item_parent', '0'),
(52, 26, '_menu_item_object_id', '26'),
(53, 26, '_menu_item_object', 'custom'),
(54, 26, '_menu_item_target', ''),
(55, 26, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(56, 26, '_menu_item_xfn', ''),
(57, 26, '_menu_item_url', 'http://localhost:8888/'),
(58, 26, '_menu_item_orphaned', '1556597077'),
(59, 27, '_menu_item_type', 'post_type'),
(60, 27, '_menu_item_menu_item_parent', '0'),
(61, 27, '_menu_item_object_id', '2'),
(62, 27, '_menu_item_object', 'page'),
(63, 27, '_menu_item_target', ''),
(64, 27, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(65, 27, '_menu_item_xfn', ''),
(66, 27, '_menu_item_url', ''),
(67, 27, '_menu_item_orphaned', '1556597077'),
(68, 28, '_menu_item_type', 'custom'),
(69, 28, '_menu_item_menu_item_parent', '0'),
(70, 28, '_menu_item_object_id', '28'),
(71, 28, '_menu_item_object', 'custom'),
(72, 28, '_menu_item_target', ''),
(73, 28, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(74, 28, '_menu_item_xfn', ''),
(75, 28, '_menu_item_url', 'http://localhost:8888/'),
(76, 28, '_menu_item_orphaned', '1556597119'),
(77, 29, '_menu_item_type', 'post_type'),
(78, 29, '_menu_item_menu_item_parent', '0'),
(79, 29, '_menu_item_object_id', '2'),
(80, 29, '_menu_item_object', 'page'),
(81, 29, '_menu_item_target', ''),
(82, 29, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(83, 29, '_menu_item_xfn', ''),
(84, 29, '_menu_item_url', ''),
(85, 29, '_menu_item_orphaned', '1556597119'),
(86, 30, '_wp_attached_file', '2019/04/cropped-testcat.jpg'),
(87, 30, '_wp_attachment_context', 'custom-header'),
(88, 30, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:1000;s:6:"height";i:249;s:4:"file";s:27:"2019/04/cropped-testcat.jpg";s:5:"sizes";a:3:{s:9:"thumbnail";a:4:{s:4:"file";s:27:"cropped-testcat-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:26:"cropped-testcat-300x75.jpg";s:5:"width";i:300;s:6:"height";i:75;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:27:"cropped-testcat-768x191.jpg";s:5:"width";i:768;s:6:"height";i:191;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}s:17:"attachment_parent";i:11;}'),
(89, 30, '_wp_attachment_custom_header_last_used_team2_theme', '1556597154'),
(90, 30, '_wp_attachment_is_custom_header', 'team2_theme'),
(91, 25, '_wp_trash_meta_status', 'publish'),
(92, 25, '_wp_trash_meta_time', '1556597154'),
(93, 31, '_menu_item_type', 'custom'),
(94, 31, '_menu_item_menu_item_parent', '0'),
(95, 31, '_menu_item_object_id', '31'),
(96, 31, '_menu_item_object', 'custom'),
(97, 31, '_menu_item_target', ''),
(98, 31, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(99, 31, '_menu_item_xfn', ''),
(100, 31, '_menu_item_url', 'http://localhost:8888/'),
(101, 31, '_menu_item_orphaned', '1556597164'),
(102, 32, '_menu_item_type', 'post_type'),
(103, 32, '_menu_item_menu_item_parent', '0'),
(104, 32, '_menu_item_object_id', '2'),
(105, 32, '_menu_item_object', 'page'),
(106, 32, '_menu_item_target', ''),
(107, 32, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(108, 32, '_menu_item_xfn', ''),
(109, 32, '_menu_item_url', ''),
(110, 32, '_menu_item_orphaned', '1556597164'),
(111, 33, '_wp_attached_file', '2019/04/cropped-testcat-1.jpg'),
(112, 33, '_wp_attachment_context', 'custom-logo'),
(113, 33, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:557;s:6:"height";i:192;s:4:"file";s:29:"2019/04/cropped-testcat-1.jpg";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:29:"cropped-testcat-1-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:29:"cropped-testcat-1-300x103.jpg";s:5:"width";i:300;s:6:"height";i:103;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(114, 34, '_wp_attached_file', '2019/04/cropped-testcat-2.jpg'),
(115, 34, '_wp_attachment_context', 'custom-logo') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(116, 34, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:557;s:6:"height";i:89;s:4:"file";s:29:"2019/04/cropped-testcat-2.jpg";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:28:"cropped-testcat-2-150x89.jpg";s:5:"width";i:150;s:6:"height";i:89;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:28:"cropped-testcat-2-300x48.jpg";s:5:"width";i:300;s:6:"height";i:48;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(117, 35, '_edit_lock', '1556597219:4'),
(118, 36, '_wp_attached_file', '2019/04/cropped-testcat-3.jpg'),
(119, 36, '_wp_attachment_context', 'site-icon'),
(120, 36, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:512;s:6:"height";i:512;s:4:"file";s:29:"2019/04/cropped-testcat-3.jpg";s:5:"sizes";a:6:{s:9:"thumbnail";a:4:{s:4:"file";s:29:"cropped-testcat-3-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:29:"cropped-testcat-3-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:13:"site_icon-270";a:4:{s:4:"file";s:29:"cropped-testcat-3-270x270.jpg";s:5:"width";i:270;s:6:"height";i:270;s:9:"mime-type";s:10:"image/jpeg";}s:13:"site_icon-192";a:4:{s:4:"file";s:29:"cropped-testcat-3-192x192.jpg";s:5:"width";i:192;s:6:"height";i:192;s:9:"mime-type";s:10:"image/jpeg";}s:13:"site_icon-180";a:4:{s:4:"file";s:29:"cropped-testcat-3-180x180.jpg";s:5:"width";i:180;s:6:"height";i:180;s:9:"mime-type";s:10:"image/jpeg";}s:12:"site_icon-32";a:4:{s:4:"file";s:27:"cropped-testcat-3-32x32.jpg";s:5:"width";i:32;s:6:"height";i:32;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(121, 35, '_wp_trash_meta_status', 'publish'),
(122, 35, '_wp_trash_meta_time', '1556597234'),
(123, 37, '_edit_lock', '1556599233:4'),
(124, 38, '_menu_item_type', 'custom'),
(125, 38, '_menu_item_menu_item_parent', '0'),
(126, 38, '_menu_item_object_id', '38'),
(127, 38, '_menu_item_object', 'custom'),
(128, 38, '_menu_item_target', ''),
(129, 38, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(130, 38, '_menu_item_xfn', ''),
(131, 38, '_menu_item_url', 'http://localhost:8888'),
(132, 37, '_wp_trash_meta_status', 'publish'),
(133, 37, '_wp_trash_meta_time', '1556599243'),
(134, 39, '_wp_trash_meta_status', 'publish'),
(135, 39, '_wp_trash_meta_time', '1556773487'),
(138, 41, '_wp_attached_file', '2019/05/COFFEECAN1.jpg'),
(139, 41, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1772;s:6:"height";i:1772;s:4:"file";s:22:"2019/05/COFFEECAN1.jpg";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:22:"COFFEECAN1-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:22:"COFFEECAN1-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:22:"COFFEECAN1-768x768.jpg";s:5:"width";i:768;s:6:"height";i:768;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:24:"COFFEECAN1-1024x1024.jpg";s:5:"width";i:1024;s:6:"height";i:1024;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"1";s:8:"keywords";a:0:{}}}'),
(140, 42, '_wp_attached_file', '2019/05/cropped-COFFEECAN1-3.jpg'),
(141, 42, '_wp_attachment_context', 'custom-header'),
(142, 42, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:480;s:6:"height";i:480;s:4:"file";s:32:"2019/05/cropped-COFFEECAN1-3.jpg";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:32:"cropped-COFFEECAN1-3-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:32:"cropped-COFFEECAN1-3-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}s:17:"attachment_parent";i:41;}'),
(143, 42, '_wp_attachment_custom_header_last_used_team02', '1556776337'),
(144, 42, '_wp_attachment_is_custom_header', 'team02'),
(145, 43, '_wp_trash_meta_status', 'publish'),
(146, 43, '_wp_trash_meta_time', '1556775618'),
(147, 44, '_edit_lock', '1556775780:4'),
(148, 44, '_customize_restore_dismissed', '1'),
(149, 45, '_edit_lock', '1556775924:4'),
(150, 45, '_wp_trash_meta_status', 'publish'),
(151, 45, '_wp_trash_meta_time', '1556775948'),
(152, 46, '_edit_lock', '1556776370:4'),
(155, 48, '_wp_attached_file', '2019/05/cropped-COFFEECAN1.png'),
(156, 48, '_wp_attachment_context', 'custom-header'),
(157, 48, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:480;s:6:"height";i:480;s:4:"file";s:30:"2019/05/cropped-COFFEECAN1.png";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:30:"cropped-COFFEECAN1-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:6:"medium";a:4:{s:4:"file";s:30:"cropped-COFFEECAN1-300x300.png";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}s:17:"attachment_parent";i:47;}'),
(158, 48, '_wp_attachment_custom_header_last_used_team02', '1556776768'),
(159, 48, '_wp_attachment_is_custom_header', 'team02'),
(160, 46, '_customize_restore_dismissed', '1'),
(161, 49, '_wp_attached_file', '2019/05/COFFEECAN1-1.png'),
(162, 49, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1772;s:6:"height";i:1772;s:4:"file";s:24:"2019/05/COFFEECAN1-1.png";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:24:"COFFEECAN1-1-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:6:"medium";a:4:{s:4:"file";s:24:"COFFEECAN1-1-300x300.png";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";}s:12:"medium_large";a:4:{s:4:"file";s:24:"COFFEECAN1-1-768x768.png";s:5:"width";i:768;s:6:"height";i:768;s:9:"mime-type";s:9:"image/png";}s:5:"large";a:4:{s:4:"file";s:26:"COFFEECAN1-1-1024x1024.png";s:5:"width";i:1024;s:6:"height";i:1024;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(163, 50, '_edit_lock', '1556776828:4'),
(164, 51, '_wp_attached_file', '2019/05/cropped-COFFEECAN1-1-1.png'),
(165, 51, '_wp_attachment_context', 'custom-header'),
(166, 51, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:240;s:6:"height";i:240;s:4:"file";s:34:"2019/05/cropped-COFFEECAN1-1-1.png";s:5:"sizes";a:1:{s:9:"thumbnail";a:4:{s:4:"file";s:34:"cropped-COFFEECAN1-1-1-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}s:17:"attachment_parent";i:49;}'),
(167, 51, '_wp_attachment_custom_header_last_used_team02', '1556776893'),
(168, 51, '_wp_attachment_is_custom_header', 'team02'),
(169, 50, '_wp_trash_meta_status', 'publish'),
(170, 50, '_wp_trash_meta_time', '1556776845'),
(171, 52, '_wp_trash_meta_status', 'publish'),
(172, 52, '_wp_trash_meta_time', '1556776893'),
(173, 53, '_wp_attached_file', '2019/05/COFFEECAN2.png'),
(174, 53, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1772;s:6:"height";i:1772;s:4:"file";s:22:"2019/05/COFFEECAN2.png";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:22:"COFFEECAN2-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:6:"medium";a:4:{s:4:"file";s:22:"COFFEECAN2-300x300.png";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";}s:12:"medium_large";a:4:{s:4:"file";s:22:"COFFEECAN2-768x768.png";s:5:"width";i:768;s:6:"height";i:768;s:9:"mime-type";s:9:"image/png";}s:5:"large";a:4:{s:4:"file";s:24:"COFFEECAN2-1024x1024.png";s:5:"width";i:1024;s:6:"height";i:1024;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(175, 54, '_wp_attached_file', '2019/05/cropped-COFFEECAN2.png'),
(176, 54, '_wp_attachment_context', 'custom-header'),
(177, 54, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:240;s:6:"height";i:240;s:4:"file";s:30:"2019/05/cropped-COFFEECAN2.png";s:5:"sizes";a:1:{s:9:"thumbnail";a:4:{s:4:"file";s:30:"cropped-COFFEECAN2-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}s:17:"attachment_parent";i:53;}'),
(178, 54, '_wp_attachment_custom_header_last_used_team02', '1556777958'),
(179, 54, '_wp_attachment_is_custom_header', 'team02'),
(180, 55, '_wp_trash_meta_status', 'publish'),
(181, 55, '_wp_trash_meta_time', '1556777958'),
(182, 56, '_wp_trash_meta_status', 'publish'),
(183, 56, '_wp_trash_meta_time', '1556778427'),
(184, 57, '_edit_lock', '1556780030:4'),
(186, 58, '_customize_changeset_uuid', 'ed01fb56-31be-4d1f-ad31-556c75447e83'),
(188, 59, '_customize_changeset_uuid', 'ed01fb56-31be-4d1f-ad31-556c75447e83'),
(190, 60, '_customize_changeset_uuid', 'ed01fb56-31be-4d1f-ad31-556c75447e83'),
(192, 61, '_customize_changeset_uuid', 'ed01fb56-31be-4d1f-ad31-556c75447e83'),
(194, 62, '_customize_changeset_uuid', 'ed01fb56-31be-4d1f-ad31-556c75447e83'),
(196, 63, '_customize_changeset_uuid', 'ed01fb56-31be-4d1f-ad31-556c75447e83'),
(197, 70, '_menu_item_type', 'post_type'),
(198, 70, '_menu_item_menu_item_parent', '0'),
(199, 70, '_menu_item_object_id', '58'),
(200, 70, '_menu_item_object', 'page'),
(201, 70, '_menu_item_target', ''),
(202, 70, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(203, 70, '_menu_item_xfn', ''),
(204, 70, '_menu_item_url', ''),
(205, 71, '_menu_item_type', 'post_type'),
(206, 71, '_menu_item_menu_item_parent', '0'),
(207, 71, '_menu_item_object_id', '59'),
(208, 71, '_menu_item_object', 'page'),
(209, 71, '_menu_item_target', ''),
(210, 71, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(211, 71, '_menu_item_xfn', ''),
(212, 71, '_menu_item_url', ''),
(213, 72, '_menu_item_type', 'post_type'),
(214, 72, '_menu_item_menu_item_parent', '0'),
(215, 72, '_menu_item_object_id', '60'),
(216, 72, '_menu_item_object', 'page'),
(217, 72, '_menu_item_target', ''),
(218, 72, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(219, 72, '_menu_item_xfn', ''),
(220, 72, '_menu_item_url', ''),
(221, 73, '_menu_item_type', 'post_type'),
(222, 73, '_menu_item_menu_item_parent', '0'),
(223, 73, '_menu_item_object_id', '61'),
(224, 73, '_menu_item_object', 'page'),
(225, 73, '_menu_item_target', '') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(226, 73, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(227, 73, '_menu_item_xfn', ''),
(228, 73, '_menu_item_url', ''),
(229, 74, '_menu_item_type', 'post_type'),
(230, 74, '_menu_item_menu_item_parent', '0'),
(231, 74, '_menu_item_object_id', '62'),
(232, 74, '_menu_item_object', 'page'),
(233, 74, '_menu_item_target', ''),
(234, 74, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(235, 74, '_menu_item_xfn', ''),
(236, 74, '_menu_item_url', ''),
(237, 75, '_menu_item_type', 'post_type'),
(238, 75, '_menu_item_menu_item_parent', '0'),
(239, 75, '_menu_item_object_id', '63'),
(240, 75, '_menu_item_object', 'page'),
(241, 75, '_menu_item_target', ''),
(242, 75, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(243, 75, '_menu_item_xfn', ''),
(244, 75, '_menu_item_url', ''),
(245, 57, '_wp_trash_meta_status', 'publish'),
(246, 57, '_wp_trash_meta_time', '1556780044'),
(248, 76, '_customize_changeset_uuid', 'b8e2c100-23e8-467d-a0d5-d2daac71ffa4'),
(249, 77, '_wp_trash_meta_status', 'publish'),
(250, 77, '_wp_trash_meta_time', '1556782851'),
(251, 76, '_edit_lock', '1556783459:4'),
(252, 79, '_wp_attached_file', '2019/05/speciality_coffee.jpg'),
(253, 79, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:724;s:6:"height";i:1024;s:4:"file";s:29:"2019/05/speciality_coffee.jpg";s:5:"sizes";a:3:{s:9:"thumbnail";a:4:{s:4:"file";s:29:"speciality_coffee-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:29:"speciality_coffee-212x300.jpg";s:5:"width";i:212;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:30:"speciality_coffee-724x1024.jpg";s:5:"width";i:724;s:6:"height";i:1024;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(254, 81, '_edit_lock', '1556782946:4'),
(255, 82, '_wp_attached_file', '2019/05/speciality_coffee-1.jpg'),
(256, 82, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:724;s:6:"height";i:1024;s:4:"file";s:31:"2019/05/speciality_coffee-1.jpg";s:5:"sizes";a:3:{s:9:"thumbnail";a:4:{s:4:"file";s:31:"speciality_coffee-1-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:31:"speciality_coffee-1-212x300.jpg";s:5:"width";i:212;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:32:"speciality_coffee-1-724x1024.jpg";s:5:"width";i:724;s:6:"height";i:1024;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(257, 83, '_wp_attached_file', '2019/05/breakfast_lunches.jpg'),
(258, 83, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:724;s:6:"height";i:1024;s:4:"file";s:29:"2019/05/breakfast_lunches.jpg";s:5:"sizes";a:3:{s:9:"thumbnail";a:4:{s:4:"file";s:29:"breakfast_lunches-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:29:"breakfast_lunches-212x300.jpg";s:5:"width";i:212;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:30:"breakfast_lunches-724x1024.jpg";s:5:"width";i:724;s:6:"height";i:1024;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(259, 84, '_wp_attached_file', '2019/05/something_sweet.jpg'),
(260, 84, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:724;s:6:"height";i:1024;s:4:"file";s:27:"2019/05/something_sweet.jpg";s:5:"sizes";a:3:{s:9:"thumbnail";a:4:{s:4:"file";s:27:"something_sweet-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:27:"something_sweet-212x300.jpg";s:5:"width";i:212;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:28:"something_sweet-724x1024.jpg";s:5:"width";i:724;s:6:"height";i:1024;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(261, 85, '_wp_attached_file', '2019/05/breakfast_lunches-1.jpg'),
(262, 85, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:724;s:6:"height";i:1024;s:4:"file";s:31:"2019/05/breakfast_lunches-1.jpg";s:5:"sizes";a:3:{s:9:"thumbnail";a:4:{s:4:"file";s:31:"breakfast_lunches-1-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:31:"breakfast_lunches-1-212x300.jpg";s:5:"width";i:212;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:32:"breakfast_lunches-1-724x1024.jpg";s:5:"width";i:724;s:6:"height";i:1024;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(263, 86, '_wp_attached_file', '2019/05/something_sweet-1.jpg'),
(264, 86, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:724;s:6:"height";i:1024;s:4:"file";s:29:"2019/05/something_sweet-1.jpg";s:5:"sizes";a:3:{s:9:"thumbnail";a:4:{s:4:"file";s:29:"something_sweet-1-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:29:"something_sweet-1-212x300.jpg";s:5:"width";i:212;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:30:"something_sweet-1-724x1024.jpg";s:5:"width";i:724;s:6:"height";i:1024;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(265, 87, '_wp_attached_file', '2019/05/speciality_coffee-2.jpg'),
(266, 87, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:724;s:6:"height";i:1024;s:4:"file";s:31:"2019/05/speciality_coffee-2.jpg";s:5:"sizes";a:3:{s:9:"thumbnail";a:4:{s:4:"file";s:31:"speciality_coffee-2-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:31:"speciality_coffee-2-212x300.jpg";s:5:"width";i:212;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:32:"speciality_coffee-2-724x1024.jpg";s:5:"width";i:724;s:6:"height";i:1024;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(267, 85, '_edit_lock', '1556783204:4'),
(268, 87, '_gallery_link_url', 'http://localhost:8888/index.php/menu/'),
(269, 87, '_gallery_link_target', '_self'),
(270, 87, '_gallery_link_rel', ''),
(271, 86, '_gallery_link_url', 'http://localhost:8888/index.php/menu/'),
(272, 86, '_gallery_link_target', '_self'),
(273, 86, '_gallery_link_rel', ''),
(274, 85, '_gallery_link_url', 'http://localhost:8888/index.php/menu/'),
(275, 85, '_gallery_link_target', '_self'),
(276, 85, '_gallery_link_rel', ''),
(277, 84, '_gallery_link_url', 'http://localhost:8888/index.php/menu/'),
(278, 84, '_gallery_link_target', '_self'),
(279, 84, '_gallery_link_rel', ''),
(280, 83, '_gallery_link_url', 'http://localhost:8888/index.php/menu/'),
(281, 83, '_gallery_link_target', '_self'),
(282, 83, '_gallery_link_rel', ''),
(283, 82, '_gallery_link_url', 'http://localhost:8888/index.php/menu/'),
(284, 82, '_gallery_link_target', '_self'),
(285, 82, '_gallery_link_rel', ''),
(286, 79, '_gallery_link_url', 'http://localhost:8888/index.php/menu/'),
(287, 79, '_gallery_link_target', '_self'),
(288, 79, '_gallery_link_rel', ''),
(289, 92, '_wp_trash_meta_status', 'publish'),
(290, 92, '_wp_trash_meta_time', '1556784027') ;

#
# End of data contents of table `wp_postmeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_posts`
#

DROP TABLE IF EXISTS `wp_posts`;


#
# Table structure of table `wp_posts`
#

CREATE TABLE `wp_posts` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_author` bigint(20) unsigned NOT NULL DEFAULT '0',
  `post_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_title` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_excerpt` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'publish',
  `comment_status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'open',
  `ping_status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'open',
  `post_password` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `post_name` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `to_ping` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `pinged` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content_filtered` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `guid` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `menu_order` int(11) NOT NULL DEFAULT '0',
  `post_type` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'post',
  `post_mime_type` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `post_name` (`post_name`(191)),
  KEY `type_status_date` (`post_type`,`post_status`,`post_date`,`ID`),
  KEY `post_parent` (`post_parent`),
  KEY `post_author` (`post_author`)
) ENGINE=InnoDB AUTO_INCREMENT=93 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_posts`
#
INSERT INTO `wp_posts` ( `ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(1, 1, '2019-04-22 00:07:39', '2019-04-22 00:07:39', '<!-- wp:paragraph -->\n<p>Welcome to WordPress. This is your first post. Edit or delete it, then start writing!</p>\n<!-- /wp:paragraph -->', 'Hello world!', '', 'publish', 'open', 'open', '', 'hello-world', '', '', '2019-04-22 00:07:39', '2019-04-22 00:07:39', '', 0, 'http://localhost:8888/?p=1', 0, 'post', '', 1),
(2, 1, '2019-04-22 00:07:39', '2019-04-22 00:07:39', '<!-- wp:paragraph -->\n<p>This is an example page. It\'s different from a blog post because it will stay in one place and will show up in your site navigation (in most themes). Most people start with an About page that introduces them to potential site visitors. It might say something like this:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:quote -->\n<blockquote class="wp-block-quote"><p>Hi there! I\'m a bike messenger by day, aspiring actor by night, and this is my website. I live in Los Angeles, have a great dog named Jack, and I like pi&#241;a coladas. (And gettin\' caught in the rain.)</p></blockquote>\n<!-- /wp:quote -->\n\n<!-- wp:paragraph -->\n<p>...or something like this:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:quote -->\n<blockquote class="wp-block-quote"><p>The XYZ Doohickey Company was founded in 1971, and has been providing quality doohickeys to the public ever since. Located in Gotham City, XYZ employs over 2,000 people and does all kinds of awesome things for the Gotham community.</p></blockquote>\n<!-- /wp:quote -->\n\n<!-- wp:paragraph -->\n<p>As a new WordPress user, you should go to <a href="http://localhost:8888/wp-admin/">your dashboard</a> to delete this page and create new pages for your content. Have fun!</p>\n<!-- /wp:paragraph -->', 'Sample Page', '', 'publish', 'closed', 'open', '', 'sample-page', '', '', '2019-04-22 00:07:39', '2019-04-22 00:07:39', '', 0, 'http://localhost:8888/?page_id=2', 0, 'page', '', 0),
(3, 1, '2019-04-22 00:07:39', '2019-04-22 00:07:39', '<!-- wp:heading --><h2>Who we are</h2><!-- /wp:heading --><!-- wp:paragraph --><p>Our website address is: http://localhost:8888.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>What personal data we collect and why we collect it</h2><!-- /wp:heading --><!-- wp:heading {"level":3} --><h3>Comments</h3><!-- /wp:heading --><!-- wp:paragraph --><p>When visitors leave comments on the site we collect the data shown in the comments form, and also the visitor&#8217;s IP address and browser user agent string to help spam detection.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>An anonymized string created from your email address (also called a hash) may be provided to the Gravatar service to see if you are using it. The Gravatar service privacy policy is available here: https://automattic.com/privacy/. After approval of your comment, your profile picture is visible to the public in the context of your comment.</p><!-- /wp:paragraph --><!-- wp:heading {"level":3} --><h3>Media</h3><!-- /wp:heading --><!-- wp:paragraph --><p>If you upload images to the website, you should avoid uploading images with embedded location data (EXIF GPS) included. Visitors to the website can download and extract any location data from images on the website.</p><!-- /wp:paragraph --><!-- wp:heading {"level":3} --><h3>Contact forms</h3><!-- /wp:heading --><!-- wp:heading {"level":3} --><h3>Cookies</h3><!-- /wp:heading --><!-- wp:paragraph --><p>If you leave a comment on our site you may opt-in to saving your name, email address and website in cookies. These are for your convenience so that you do not have to fill in your details again when you leave another comment. These cookies will last for one year.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>If you have an account and you log in to this site, we will set a temporary cookie to determine if your browser accepts cookies. This cookie contains no personal data and is discarded when you close your browser.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>When you log in, we will also set up several cookies to save your login information and your screen display choices. Login cookies last for two days, and screen options cookies last for a year. If you select &quot;Remember Me&quot;, your login will persist for two weeks. If you log out of your account, the login cookies will be removed.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>If you edit or publish an article, an additional cookie will be saved in your browser. This cookie includes no personal data and simply indicates the post ID of the article you just edited. It expires after 1 day.</p><!-- /wp:paragraph --><!-- wp:heading {"level":3} --><h3>Embedded content from other websites</h3><!-- /wp:heading --><!-- wp:paragraph --><p>Articles on this site may include embedded content (e.g. videos, images, articles, etc.). Embedded content from other websites behaves in the exact same way as if the visitor has visited the other website.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>These websites may collect data about you, use cookies, embed additional third-party tracking, and monitor your interaction with that embedded content, including tracking your interaction with the embedded content if you have an account and are logged in to that website.</p><!-- /wp:paragraph --><!-- wp:heading {"level":3} --><h3>Analytics</h3><!-- /wp:heading --><!-- wp:heading --><h2>Who we share your data with</h2><!-- /wp:heading --><!-- wp:heading --><h2>How long we retain your data</h2><!-- /wp:heading --><!-- wp:paragraph --><p>If you leave a comment, the comment and its metadata are retained indefinitely. This is so we can recognize and approve any follow-up comments automatically instead of holding them in a moderation queue.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>For users that register on our website (if any), we also store the personal information they provide in their user profile. All users can see, edit, or delete their personal information at any time (except they cannot change their username). Website administrators can also see and edit that information.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>What rights you have over your data</h2><!-- /wp:heading --><!-- wp:paragraph --><p>If you have an account on this site, or have left comments, you can request to receive an exported file of the personal data we hold about you, including any data you have provided to us. You can also request that we erase any personal data we hold about you. This does not include any data we are obliged to keep for administrative, legal, or security purposes.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Where we send your data</h2><!-- /wp:heading --><!-- wp:paragraph --><p>Visitor comments may be checked through an automated spam detection service.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Your contact information</h2><!-- /wp:heading --><!-- wp:heading --><h2>Additional information</h2><!-- /wp:heading --><!-- wp:heading {"level":3} --><h3>How we protect your data</h3><!-- /wp:heading --><!-- wp:heading {"level":3} --><h3>What data breach procedures we have in place</h3><!-- /wp:heading --><!-- wp:heading {"level":3} --><h3>What third parties we receive data from</h3><!-- /wp:heading --><!-- wp:heading {"level":3} --><h3>What automated decision making and/or profiling we do with user data</h3><!-- /wp:heading --><!-- wp:heading {"level":3} --><h3>Industry regulatory disclosure requirements</h3><!-- /wp:heading -->', 'Privacy Policy', '', 'draft', 'closed', 'open', '', 'privacy-policy', '', '', '2019-04-22 00:07:39', '2019-04-22 00:07:39', '', 0, 'http://localhost:8888/?page_id=3', 0, 'page', '', 0),
(5, 2, '2019-04-22 10:40:25', '2019-04-22 00:40:25', '', 'Auto Draft', '', 'trash', 'open', 'open', '', '__trashed', '', '', '2019-04-22 10:40:25', '2019-04-22 00:40:25', '', 0, 'http://localhost:8888/?p=5', 0, 'post', '', 0),
(6, 1, '2019-04-22 10:40:25', '2019-04-22 00:40:25', '', 'Auto Draft', '', 'inherit', 'closed', 'closed', '', '5-revision-v1', '', '', '2019-04-22 10:40:25', '2019-04-22 00:40:25', '', 5, 'http://localhost:8888/index.php/2019/04/22/5-revision-v1/', 0, 'revision', '', 0),
(11, 1, '2019-04-23 09:53:20', '2019-04-22 23:53:20', '', 'testcat', '', 'inherit', 'open', 'closed', '', 'testcat', '', '', '2019-04-23 09:53:20', '2019-04-22 23:53:20', '', 0, 'http://localhost:8888/wp-content/uploads/2019/04/testcat.jpg', 0, 'attachment', 'image/jpeg', 0),
(12, 1, '2019-04-23 09:54:10', '2019-04-22 23:54:10', '<!-- wp:paragraph -->\n<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. </p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>I am making changes. still trying to make changes</p>\n<!-- /wp:paragraph -->', 'Test Post', '', 'publish', 'open', 'open', '', 'test-post', '', '', '2019-04-23 19:53:17', '2019-04-23 09:53:17', '', 0, 'http://localhost:8888/?p=12', 0, 'post', '', 0),
(13, 1, '2019-04-23 09:54:10', '2019-04-22 23:54:10', '<!-- wp:image {"id":11} -->\n<figure class="wp-block-image"><img src="http://localhost:8888/wp-content/uploads/2019/04/testcat.jpg" alt="" class="wp-image-11"/></figure>\n<!-- /wp:image -->', 'Test Post', '', 'inherit', 'closed', 'closed', '', '12-revision-v1', '', '', '2019-04-23 09:54:10', '2019-04-22 23:54:10', '', 12, 'http://localhost:8888/index.php/2019/04/23/12-revision-v1/', 0, 'revision', '', 0),
(14, 1, '2019-04-23 09:54:58', '2019-04-22 23:54:58', '<!-- wp:paragraph -->\n<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. </p>\n<!-- /wp:paragraph -->', 'Test Post', '', 'inherit', 'closed', 'closed', '', '12-revision-v1', '', '', '2019-04-23 09:54:58', '2019-04-22 23:54:58', '', 12, 'http://localhost:8888/index.php/2019/04/23/12-revision-v1/', 0, 'revision', '', 0),
(15, 3, '2019-04-23 15:23:11', '2019-04-23 05:23:11', '{"blogdescription":{"value":"sneaky test changes","type":"option","user_id":3,"date_modified_gmt":"2019-04-23 05:23:11"}}', '', '', 'trash', 'closed', 'closed', '', '69be6272-39c7-4341-8f8d-9ac303aee996', '', '', '2019-04-23 15:23:11', '2019-04-23 05:23:11', '', 0, 'http://localhost:8888/index.php/2019/04/23/69be6272-39c7-4341-8f8d-9ac303aee996/', 0, 'customize_changeset', '', 0),
(16, 3, '2019-04-23 15:33:07', '2019-04-23 05:33:07', '{"blogdescription":{"value":"sneaky test changes1","type":"option","user_id":3,"date_modified_gmt":"2019-04-23 05:33:07"}}', '', '', 'trash', 'closed', 'closed', '', 'ac778be8-eac6-434d-b8f1-4594b20d3795', '', '', '2019-04-23 15:33:07', '2019-04-23 05:33:07', '', 0, 'http://localhost:8888/index.php/2019/04/23/ac778be8-eac6-434d-b8f1-4594b20d3795/', 0, 'customize_changeset', '', 0),
(17, 3, '2019-04-23 15:38:44', '2019-04-23 05:38:44', '{"blogdescription":{"value":"sneaky","type":"option","user_id":3,"date_modified_gmt":"2019-04-23 05:38:44"}}', '', '', 'trash', 'closed', 'closed', '', '469f60f0-0f4b-4107-a1b9-aef40952f35f', '', '', '2019-04-23 15:38:44', '2019-04-23 05:38:44', '', 0, 'http://localhost:8888/index.php/2019/04/23/469f60f0-0f4b-4107-a1b9-aef40952f35f/', 0, 'customize_changeset', '', 0),
(18, 3, '2019-04-23 19:08:57', '2019-04-23 09:08:57', '<!-- wp:paragraph -->\n<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. </p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>I am making changes.</p>\n<!-- /wp:paragraph -->', 'Test Post', '', 'inherit', 'closed', 'closed', '', '12-revision-v1', '', '', '2019-04-23 19:08:57', '2019-04-23 09:08:57', '', 12, 'http://localhost:8888/index.php/2019/04/23/12-revision-v1/', 0, 'revision', '', 0),
(19, 3, '2019-04-23 19:53:17', '2019-04-23 09:53:17', '<!-- wp:paragraph -->\n<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. </p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>I am making changes. still trying to make changes</p>\n<!-- /wp:paragraph -->', 'Test Post', '', 'inherit', 'closed', 'closed', '', '12-revision-v1', '', '', '2019-04-23 19:53:17', '2019-04-23 09:53:17', '', 12, 'http://localhost:8888/index.php/2019/04/23/12-revision-v1/', 0, 'revision', '', 0),
(20, 3, '2019-04-23 20:04:17', '2019-04-23 10:04:17', '<!-- wp:paragraph -->\n<p>ertybytejnyturej</p>\n<!-- /wp:paragraph -->', 'tfdshbtreub', '', 'publish', 'open', 'open', '', 'tfdshbtreub', '', '', '2019-04-23 20:04:17', '2019-04-23 10:04:17', '', 0, 'http://localhost:8888/?p=20', 0, 'post', '', 0),
(21, 3, '2019-04-23 20:04:17', '2019-04-23 10:04:17', '<!-- wp:paragraph -->\n<p>ertybytejnyturej</p>\n<!-- /wp:paragraph -->', 'tfdshbtreub', '', 'inherit', 'closed', 'closed', '', '20-revision-v1', '', '', '2019-04-23 20:04:17', '2019-04-23 10:04:17', '', 20, 'http://localhost:8888/index.php/2019/04/23/20-revision-v1/', 0, 'revision', '', 0),
(22, 4, '2019-04-30 13:26:01', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'open', 'open', '', '', '', '', '2019-04-30 13:26:01', '0000-00-00 00:00:00', '', 0, 'http://localhost:8888/?p=22', 0, 'post', '', 0),
(23, 4, '2019-04-30 14:02:50', '0000-00-00 00:00:00', '', 'Home', '', 'draft', 'closed', 'closed', '', '', '', '', '2019-04-30 14:02:50', '0000-00-00 00:00:00', '', 0, 'http://localhost:8888/?p=23', 1, 'nav_menu_item', '', 0),
(24, 4, '2019-04-30 14:02:50', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2019-04-30 14:02:50', '0000-00-00 00:00:00', '', 0, 'http://localhost:8888/?p=24', 1, 'nav_menu_item', '', 0),
(25, 4, '2019-04-30 14:05:54', '2019-04-30 04:05:54', '{"show_on_front":{"value":"page","type":"option","user_id":4,"date_modified_gmt":"2019-04-30 04:03:33"},"team2_theme::background_color":{"value":"#ffffff","type":"theme_mod","user_id":4,"date_modified_gmt":"2019-04-30 04:05:16"},"team2_theme::header_image":{"value":"http:\\/\\/localhost:8888\\/wp-content\\/uploads\\/2019\\/04\\/cropped-testcat.jpg","type":"theme_mod","user_id":4,"date_modified_gmt":"2019-04-30 04:05:54"},"team2_theme::header_image_data":{"value":{"url":"http:\\/\\/localhost:8888\\/wp-content\\/uploads\\/2019\\/04\\/cropped-testcat.jpg","thumbnail_url":"http:\\/\\/localhost:8888\\/wp-content\\/uploads\\/2019\\/04\\/cropped-testcat.jpg","timestamp":1556597148395,"attachment_id":30,"width":1000,"height":249},"type":"theme_mod","user_id":4,"date_modified_gmt":"2019-04-30 04:05:54"}}', '', '', 'trash', 'closed', 'closed', '', '7349ca12-e895-4c32-87a5-94b61f8ad989', '', '', '2019-04-30 14:05:54', '2019-04-30 04:05:54', '', 0, 'http://localhost:8888/?p=25', 0, 'customize_changeset', '', 0),
(26, 4, '2019-04-30 14:04:37', '0000-00-00 00:00:00', '', 'Home', '', 'draft', 'closed', 'closed', '', '', '', '', '2019-04-30 14:04:37', '0000-00-00 00:00:00', '', 0, 'http://localhost:8888/?p=26', 1, 'nav_menu_item', '', 0),
(27, 4, '2019-04-30 14:04:37', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2019-04-30 14:04:37', '0000-00-00 00:00:00', '', 0, 'http://localhost:8888/?p=27', 1, 'nav_menu_item', '', 0),
(28, 4, '2019-04-30 14:05:19', '0000-00-00 00:00:00', '', 'Home', '', 'draft', 'closed', 'closed', '', '', '', '', '2019-04-30 14:05:19', '0000-00-00 00:00:00', '', 0, 'http://localhost:8888/?p=28', 1, 'nav_menu_item', '', 0),
(29, 4, '2019-04-30 14:05:19', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2019-04-30 14:05:19', '0000-00-00 00:00:00', '', 0, 'http://localhost:8888/?p=29', 1, 'nav_menu_item', '', 0),
(30, 4, '2019-04-30 14:05:48', '2019-04-30 04:05:48', '', 'cropped-testcat.jpg', '', 'inherit', 'open', 'closed', '', 'cropped-testcat-jpg', '', '', '2019-04-30 14:05:48', '2019-04-30 04:05:48', '', 0, 'http://localhost:8888/wp-content/uploads/2019/04/cropped-testcat.jpg', 0, 'attachment', 'image/jpeg', 0),
(31, 4, '2019-04-30 14:06:03', '0000-00-00 00:00:00', '', 'Home', '', 'draft', 'closed', 'closed', '', '', '', '', '2019-04-30 14:06:03', '0000-00-00 00:00:00', '', 0, 'http://localhost:8888/?p=31', 1, 'nav_menu_item', '', 0),
(32, 4, '2019-04-30 14:06:04', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2019-04-30 14:06:04', '0000-00-00 00:00:00', '', 0, 'http://localhost:8888/?p=32', 1, 'nav_menu_item', '', 0),
(33, 4, '2019-04-30 14:06:34', '2019-04-30 04:06:34', 'http://localhost:8888/wp-content/uploads/2019/04/cropped-testcat-1.jpg', 'cropped-testcat-1.jpg', '', 'inherit', 'open', 'closed', '', 'cropped-testcat-1-jpg', '', '', '2019-04-30 14:06:34', '2019-04-30 04:06:34', '', 0, 'http://localhost:8888/wp-content/uploads/2019/04/cropped-testcat-1.jpg', 0, 'attachment', 'image/jpeg', 0),
(34, 4, '2019-04-30 14:06:52', '2019-04-30 04:06:52', 'http://localhost:8888/wp-content/uploads/2019/04/cropped-testcat-2.jpg', 'cropped-testcat-2.jpg', '', 'inherit', 'open', 'closed', '', 'cropped-testcat-2-jpg', '', '', '2019-04-30 14:06:52', '2019-04-30 04:06:52', '', 0, 'http://localhost:8888/wp-content/uploads/2019/04/cropped-testcat-2.jpg', 0, 'attachment', 'image/jpeg', 0),
(35, 4, '2019-04-30 14:07:14', '2019-04-30 04:07:14', '{"team2_theme::custom_logo":{"value":34,"type":"theme_mod","user_id":4,"date_modified_gmt":"2019-04-30 04:06:59"},"site_icon":{"value":36,"type":"option","user_id":4,"date_modified_gmt":"2019-04-30 04:07:14"}}', '', '', 'trash', 'closed', 'closed', '', '708a124c-441e-469e-8460-bd0d2d2b9e50', '', '', '2019-04-30 14:07:14', '2019-04-30 04:07:14', '', 0, 'http://localhost:8888/?p=35', 0, 'customize_changeset', '', 0),
(36, 4, '2019-04-30 14:07:09', '2019-04-30 04:07:09', 'http://localhost:8888/wp-content/uploads/2019/04/cropped-testcat-3.jpg', 'cropped-testcat-3.jpg', '', 'inherit', 'open', 'closed', '', 'cropped-testcat-3-jpg', '', '', '2019-04-30 14:07:09', '2019-04-30 04:07:09', '', 0, 'http://localhost:8888/wp-content/uploads/2019/04/cropped-testcat-3.jpg', 0, 'attachment', 'image/jpeg', 0),
(37, 4, '2019-04-30 14:40:43', '2019-04-30 04:40:43', '{"team2_theme::nav_menu_locations[menu-1]":{"value":-1857964654009088000,"type":"theme_mod","user_id":4,"date_modified_gmt":"2019-04-30 04:10:15"},"nav_menu[-1857964654009088000]":{"value":{"name":"Header-Nav","description":"","parent":0,"auto_add":false},"type":"nav_menu","user_id":4,"date_modified_gmt":"2019-04-30 04:10:15"},"nav_menu_item[-5240733991381651000]":{"value":{"object_id":0,"object":"","menu_item_parent":0,"position":1,"type":"custom","title":"Home","url":"http:\\/\\/localhost:8888","target":"","attr_title":"","description":"","classes":"","xfn":"","status":"publish","original_title":"Home","nav_menu_term_id":-1857964654009088000,"_invalid":false,"type_label":"Custom Link"},"type":"nav_menu_item","user_id":4,"date_modified_gmt":"2019-04-30 04:10:15"}}', '', '', 'trash', 'closed', 'closed', '', '324a40ec-f065-4abe-ba0c-788c40f30e58', '', '', '2019-04-30 14:40:43', '2019-04-30 04:40:43', '', 0, 'http://localhost:8888/?p=37', 0, 'customize_changeset', '', 0),
(38, 4, '2019-04-30 14:40:43', '2019-04-30 04:40:43', '', 'Home', '', 'publish', 'closed', 'closed', '', 'home', '', '', '2019-04-30 14:40:43', '2019-04-30 04:40:43', '', 0, 'http://localhost:8888/index.php/2019/04/30/home/', 1, 'nav_menu_item', '', 0),
(39, 4, '2019-05-02 15:04:47', '2019-05-02 05:04:47', '{"site_icon":{"value":"","type":"option","user_id":4,"date_modified_gmt":"2019-05-02 05:04:47"},"team2_theme::custom_logo":{"value":"","type":"theme_mod","user_id":4,"date_modified_gmt":"2019-05-02 05:04:47"}}', '', '', 'trash', 'closed', 'closed', '', 'cda496e4-68f7-46b1-9787-309f42648aa9', '', '', '2019-05-02 15:04:47', '2019-05-02 05:04:47', '', 0, 'http://localhost:8888/index.php/2019/05/02/cda496e4-68f7-46b1-9787-309f42648aa9/', 0, 'customize_changeset', '', 0),
(41, 4, '2019-05-02 15:40:01', '2019-05-02 05:40:01', '', 'COFFEECAN1', '', 'inherit', 'open', 'closed', '', 'coffeecan1', '', '', '2019-05-02 15:40:01', '2019-05-02 05:40:01', '', 0, 'http://localhost:8888/wp-content/uploads/2019/05/COFFEECAN1.jpg', 0, 'attachment', 'image/jpeg', 0),
(42, 4, '2019-05-02 15:52:17', '2019-05-02 05:52:17', '', 'cropped-COFFEECAN1-3.jpg', '', 'inherit', 'closed', 'closed', '', 'cropped-coffeecan1-jpg', '', '', '2019-05-02 15:52:17', '2019-05-02 05:52:17', '', 0, 'http://localhost:8888/wp-content/uploads/2019/05/cropped-COFFEECAN1.jpg', 0, 'attachment', 'image/jpeg', 0),
(43, 4, '2019-05-02 15:40:18', '2019-05-02 05:40:18', '{"team02::header_image":{"value":"http:\\/\\/localhost:8888\\/wp-content\\/uploads\\/2019\\/05\\/cropped-COFFEECAN1.jpg","type":"theme_mod","user_id":4,"date_modified_gmt":"2019-05-02 05:40:18"},"team02::header_image_data":{"value":{"url":"http:\\/\\/localhost:8888\\/wp-content\\/uploads\\/2019\\/05\\/cropped-COFFEECAN1.jpg","thumbnail_url":"http:\\/\\/localhost:8888\\/wp-content\\/uploads\\/2019\\/05\\/cropped-COFFEECAN1.jpg","timestamp":1556775615840,"attachment_id":42,"width":960,"height":960},"type":"theme_mod","user_id":4,"date_modified_gmt":"2019-05-02 05:40:18"}}', '', '', 'trash', 'closed', 'closed', '', '7a85dc36-ec4d-46c3-b3e2-0d2a806d4057', '', '', '2019-05-02 15:40:18', '2019-05-02 05:40:18', '', 0, 'http://localhost:8888/index.php/2019/05/02/7a85dc36-ec4d-46c3-b3e2-0d2a806d4057/', 0, 'customize_changeset', '', 0),
(44, 4, '2019-05-02 15:43:00', '0000-00-00 00:00:00', '{"team02::header_image":{"value":"http:\\/\\/localhost:8888\\/wp-content\\/uploads\\/2019\\/05\\/cropped-COFFEECAN1-1.jpg","type":"theme_mod","user_id":4,"date_modified_gmt":"2019-05-02 05:43:00"},"team02::header_image_data":{"value":{"url":"http:\\/\\/localhost:8888\\/wp-content\\/uploads\\/2019\\/05\\/cropped-COFFEECAN1-1.jpg","thumbnail_url":"http:\\/\\/localhost:8888\\/wp-content\\/uploads\\/2019\\/05\\/cropped-COFFEECAN1-1.jpg","timestamp":1556775768085,"attachment_id":42,"width":480,"height":480},"type":"theme_mod","user_id":4,"date_modified_gmt":"2019-05-02 05:43:00"}}', '', '', 'auto-draft', 'closed', 'closed', '', 'd9191c53-cca9-43d4-9b17-9ed391cda55b', '', '', '2019-05-02 15:43:00', '0000-00-00 00:00:00', '', 0, 'http://localhost:8888/?p=44', 0, 'customize_changeset', '', 0),
(45, 4, '2019-05-02 15:45:48', '2019-05-02 05:45:48', '{"team02::header_image":{"value":"http:\\/\\/localhost:8888\\/wp-content\\/uploads\\/2019\\/05\\/cropped-COFFEECAN1-2.jpg","type":"theme_mod","user_id":4,"date_modified_gmt":"2019-05-02 05:44:09"},"team02::header_image_data":{"value":{"url":"http:\\/\\/localhost:8888\\/wp-content\\/uploads\\/2019\\/05\\/cropped-COFFEECAN1-2.jpg","thumbnail_url":"http:\\/\\/localhost:8888\\/wp-content\\/uploads\\/2019\\/05\\/cropped-COFFEECAN1-2.jpg","timestamp":1556775789151,"attachment_id":42,"width":240,"height":240},"type":"theme_mod","user_id":4,"date_modified_gmt":"2019-05-02 05:44:09"}}', '', '', 'trash', 'closed', 'closed', '', 'b368d7dd-5e30-4891-83e6-f3a162d399ec', '', '', '2019-05-02 15:45:48', '2019-05-02 05:45:48', '', 0, 'http://localhost:8888/?p=45', 0, 'customize_changeset', '', 0),
(46, 4, '2019-05-02 15:52:50', '0000-00-00 00:00:00', '{"team02::header_image":{"value":"http:\\/\\/localhost:8888\\/wp-content\\/uploads\\/2019\\/05\\/cropped-COFFEECAN1-3.jpg","type":"theme_mod","user_id":4,"date_modified_gmt":"2019-05-02 05:52:50"},"team02::header_image_data":{"value":{"url":"http:\\/\\/localhost:8888\\/wp-content\\/uploads\\/2019\\/05\\/cropped-COFFEECAN1-3.jpg","thumbnail_url":"http:\\/\\/localhost:8888\\/wp-content\\/uploads\\/2019\\/05\\/cropped-COFFEECAN1-3.jpg","timestamp":1556776337740,"attachment_id":42,"width":480,"height":480},"type":"theme_mod","user_id":4,"date_modified_gmt":"2019-05-02 05:52:50"}}', '', '', 'auto-draft', 'closed', 'closed', '', 'b1a3a6bc-6291-4d20-8b13-b209769db2e6', '', '', '2019-05-02 15:52:50', '0000-00-00 00:00:00', '', 0, 'http://localhost:8888/?p=46', 0, 'customize_changeset', '', 0),
(48, 4, '2019-05-02 15:59:27', '2019-05-02 05:59:27', '', 'cropped-COFFEECAN1.png', '', 'inherit', 'open', 'closed', '', 'cropped-coffeecan1-png', '', '', '2019-05-02 15:59:27', '2019-05-02 05:59:27', '', 0, 'http://localhost:8888/wp-content/uploads/2019/05/cropped-COFFEECAN1.png', 0, 'attachment', 'image/png', 0),
(49, 4, '2019-05-02 16:00:25', '2019-05-02 06:00:25', '', 'COFFEECAN1', '', 'inherit', 'open', 'closed', '', 'coffeecan1-3', '', '', '2019-05-02 16:00:25', '2019-05-02 06:00:25', '', 0, 'http://localhost:8888/wp-content/uploads/2019/05/COFFEECAN1-1.png', 0, 'attachment', 'image/png', 0),
(50, 4, '2019-05-02 16:00:45', '2019-05-02 06:00:45', '{"team02::header_image":{"value":"http:\\/\\/localhost:8888\\/wp-content\\/uploads\\/2019\\/05\\/cropped-COFFEECAN1-1.png","type":"theme_mod","user_id":4,"date_modified_gmt":"2019-05-02 06:00:45"},"team02::header_image_data":{"value":{"url":"http:\\/\\/localhost:8888\\/wp-content\\/uploads\\/2019\\/05\\/cropped-COFFEECAN1-1.png","thumbnail_url":"http:\\/\\/localhost:8888\\/wp-content\\/uploads\\/2019\\/05\\/cropped-COFFEECAN1-1.png","timestamp":1556776841700,"attachment_id":51,"width":480,"height":480},"type":"theme_mod","user_id":4,"date_modified_gmt":"2019-05-02 06:00:45"}}', '', '', 'trash', 'closed', 'closed', '', 'a70d3abe-982d-4588-8e42-b005c2bbfb24', '', '', '2019-05-02 16:00:45', '2019-05-02 06:00:45', '', 0, 'http://localhost:8888/?p=50', 0, 'customize_changeset', '', 0),
(51, 4, '2019-05-02 16:01:30', '2019-05-02 06:01:30', '', 'cropped-COFFEECAN1-1-1.png', '', 'inherit', 'closed', 'closed', '', 'cropped-coffeecan1-1-png', '', '', '2019-05-02 16:01:30', '2019-05-02 06:01:30', '', 0, 'http://localhost:8888/wp-content/uploads/2019/05/cropped-COFFEECAN1-1.png', 0, 'attachment', 'image/png', 0),
(52, 4, '2019-05-02 16:01:33', '2019-05-02 06:01:33', '{"team02::header_image":{"value":"http:\\/\\/localhost:8888\\/wp-content\\/uploads\\/2019\\/05\\/cropped-COFFEECAN1-1-1.png","type":"theme_mod","user_id":4,"date_modified_gmt":"2019-05-02 06:01:33"},"team02::header_image_data":{"value":{"url":"http:\\/\\/localhost:8888\\/wp-content\\/uploads\\/2019\\/05\\/cropped-COFFEECAN1-1-1.png","thumbnail_url":"http:\\/\\/localhost:8888\\/wp-content\\/uploads\\/2019\\/05\\/cropped-COFFEECAN1-1-1.png","timestamp":1556776891000,"attachment_id":51,"width":240,"height":240},"type":"theme_mod","user_id":4,"date_modified_gmt":"2019-05-02 06:01:33"}}', '', '', 'trash', 'closed', 'closed', '', '0a3ed8d6-d340-4186-848b-d76293339127', '', '', '2019-05-02 16:01:33', '2019-05-02 06:01:33', '', 0, 'http://localhost:8888/index.php/2019/05/02/0a3ed8d6-d340-4186-848b-d76293339127/', 0, 'customize_changeset', '', 0),
(53, 4, '2019-05-02 16:19:12', '2019-05-02 06:19:12', '', 'COFFEECAN2', '', 'inherit', 'open', 'closed', '', 'coffeecan2', '', '', '2019-05-02 16:19:12', '2019-05-02 06:19:12', '', 0, 'http://localhost:8888/wp-content/uploads/2019/05/COFFEECAN2.png', 0, 'attachment', 'image/png', 0),
(54, 4, '2019-05-02 16:19:15', '2019-05-02 06:19:15', '', 'cropped-COFFEECAN2.png', '', 'inherit', 'open', 'closed', '', 'cropped-coffeecan2-png', '', '', '2019-05-02 16:19:15', '2019-05-02 06:19:15', '', 0, 'http://localhost:8888/wp-content/uploads/2019/05/cropped-COFFEECAN2.png', 0, 'attachment', 'image/png', 0),
(55, 4, '2019-05-02 16:19:18', '2019-05-02 06:19:18', '{"team02::header_image":{"value":"http:\\/\\/localhost:8888\\/wp-content\\/uploads\\/2019\\/05\\/cropped-COFFEECAN2.png","type":"theme_mod","user_id":4,"date_modified_gmt":"2019-05-02 06:19:18"},"team02::header_image_data":{"value":{"url":"http:\\/\\/localhost:8888\\/wp-content\\/uploads\\/2019\\/05\\/cropped-COFFEECAN2.png","thumbnail_url":"http:\\/\\/localhost:8888\\/wp-content\\/uploads\\/2019\\/05\\/cropped-COFFEECAN2.png","timestamp":1556777955812,"attachment_id":54,"width":240,"height":240},"type":"theme_mod","user_id":4,"date_modified_gmt":"2019-05-02 06:19:18"}}', '', '', 'trash', 'closed', 'closed', '', 'bbfb718c-4590-4bfc-b569-e3265bbd78e1', '', '', '2019-05-02 16:19:18', '2019-05-02 06:19:18', '', 0, 'http://localhost:8888/index.php/2019/05/02/bbfb718c-4590-4bfc-b569-e3265bbd78e1/', 0, 'customize_changeset', '', 0),
(56, 4, '2019-05-02 16:27:07', '2019-05-02 06:27:07', '{"blogname":{"value":"","type":"option","user_id":4,"date_modified_gmt":"2019-05-02 06:27:07"},"blogdescription":{"value":"","type":"option","user_id":4,"date_modified_gmt":"2019-05-02 06:27:07"}}', '', '', 'trash', 'closed', 'closed', '', 'dc49d3c5-3bbd-4059-89be-bf54812b9d7f', '', '', '2019-05-02 16:27:07', '2019-05-02 06:27:07', '', 0, 'http://localhost:8888/index.php/2019/05/02/dc49d3c5-3bbd-4059-89be-bf54812b9d7f/', 0, 'customize_changeset', '', 0),
(57, 4, '2019-05-02 16:54:04', '2019-05-02 06:54:04', '{"nav_menu_item[-6502967711539096000]":{"value":false,"type":"nav_menu_item","user_id":4,"date_modified_gmt":"2019-05-02 06:52:48"},"nav_menus_created_posts":{"value":[58,59,60,61,62,63],"type":"option","user_id":4,"date_modified_gmt":"2019-05-02 06:53:50"},"nav_menu_item[-2057160511200430000]":{"value":{"object_id":58,"object":"page","menu_item_parent":0,"position":2,"type":"post_type","title":"Menu","url":"http:\\/\\/localhost:8888\\/?page_id=58","target":"","attr_title":"","description":"","classes":"","xfn":"","status":"publish","original_title":"Menu","nav_menu_term_id":2,"_invalid":false,"type_label":"Page"},"type":"nav_menu_item","user_id":4,"date_modified_gmt":"2019-05-02 06:53:03"},"nav_menu_item[-8922760587723422000]":{"value":{"object_id":59,"object":"page","menu_item_parent":0,"position":3,"type":"post_type","title":"Events","url":"http:\\/\\/localhost:8888\\/?page_id=59","target":"","attr_title":"","description":"","classes":"","xfn":"","status":"publish","original_title":"Events","nav_menu_term_id":2,"_invalid":false,"type_label":"Page"},"type":"nav_menu_item","user_id":4,"date_modified_gmt":"2019-05-02 06:54:04"},"nav_menu_item[-4799431251798927000]":{"value":{"object_id":60,"object":"page","menu_item_parent":0,"position":4,"type":"post_type","title":"Services","url":"http:\\/\\/localhost:8888\\/?page_id=60","target":"","attr_title":"","description":"","classes":"","xfn":"","status":"publish","original_title":"Services","nav_menu_term_id":2,"_invalid":false,"type_label":"Page"},"type":"nav_menu_item","user_id":4,"date_modified_gmt":"2019-05-02 06:54:04"},"nav_menu_item[-2875478256696258600]":{"value":{"object_id":61,"object":"page","menu_item_parent":0,"position":6,"type":"post_type","title":"About Us","url":"http:\\/\\/localhost:8888\\/?page_id=61","target":"","attr_title":"","description":"","classes":"","xfn":"","status":"publish","original_title":"About Us","nav_menu_term_id":2,"_invalid":false,"type_label":"Page"},"type":"nav_menu_item","user_id":4,"date_modified_gmt":"2019-05-02 06:53:50"},"nav_menu_item[-8811279745079572000]":{"value":{"object_id":62,"object":"page","menu_item_parent":0,"position":7,"type":"post_type","title":"Apply Now","url":"http:\\/\\/localhost:8888\\/?page_id=62","target":"","attr_title":"","description":"","classes":"","xfn":"","status":"publish","original_title":"Apply Now","nav_menu_term_id":2,"_invalid":false,"type_label":"Page"},"type":"nav_menu_item","user_id":4,"date_modified_gmt":"2019-05-02 06:53:50"},"nav_menu_item[-7923958615288404000]":{"value":{"object_id":63,"object":"page","menu_item_parent":0,"position":5,"type":"post_type","title":"Shop","url":"http:\\/\\/localhost:8888\\/?page_id=63","target":"","attr_title":"","description":"","classes":"","xfn":"","status":"publish","original_title":"Shop","nav_menu_term_id":2,"_invalid":false,"type_label":"Page"},"type":"nav_menu_item","user_id":4,"date_modified_gmt":"2019-05-02 06:54:04"}}', '', '', 'trash', 'closed', 'closed', '', 'ed01fb56-31be-4d1f-ad31-556c75447e83', '', '', '2019-05-02 16:54:04', '2019-05-02 06:54:04', '', 0, 'http://localhost:8888/?p=57', 0, 'customize_changeset', '', 0),
(58, 4, '2019-05-02 16:54:04', '2019-05-02 06:54:04', '', 'Menu', '', 'publish', 'closed', 'closed', '', 'menu', '', '', '2019-05-02 16:54:04', '2019-05-02 06:54:04', '', 0, 'http://localhost:8888/?page_id=58', 0, 'page', '', 0),
(59, 4, '2019-05-02 16:54:04', '2019-05-02 06:54:04', '', 'Events', '', 'publish', 'closed', 'closed', '', 'events', '', '', '2019-05-02 16:54:04', '2019-05-02 06:54:04', '', 0, 'http://localhost:8888/?page_id=59', 0, 'page', '', 0),
(60, 4, '2019-05-02 16:54:04', '2019-05-02 06:54:04', '', 'Services', '', 'publish', 'closed', 'closed', '', 'services', '', '', '2019-05-02 16:54:04', '2019-05-02 06:54:04', '', 0, 'http://localhost:8888/?page_id=60', 0, 'page', '', 0),
(61, 4, '2019-05-02 16:54:04', '2019-05-02 06:54:04', '', 'About Us', '', 'publish', 'closed', 'closed', '', 'about-us', '', '', '2019-05-02 16:54:04', '2019-05-02 06:54:04', '', 0, 'http://localhost:8888/?page_id=61', 0, 'page', '', 0),
(62, 4, '2019-05-02 16:54:04', '2019-05-02 06:54:04', '', 'Apply Now', '', 'publish', 'closed', 'closed', '', 'apply-now', '', '', '2019-05-02 16:54:04', '2019-05-02 06:54:04', '', 0, 'http://localhost:8888/?page_id=62', 0, 'page', '', 0),
(63, 4, '2019-05-02 16:54:04', '2019-05-02 06:54:04', '', 'Shop', '', 'publish', 'closed', 'closed', '', 'shop', '', '', '2019-05-02 16:54:04', '2019-05-02 06:54:04', '', 0, 'http://localhost:8888/?page_id=63', 0, 'page', '', 0),
(64, 4, '2019-05-02 16:54:04', '2019-05-02 06:54:04', '', 'Menu', '', 'inherit', 'closed', 'closed', '', '58-revision-v1', '', '', '2019-05-02 16:54:04', '2019-05-02 06:54:04', '', 58, 'http://localhost:8888/index.php/2019/05/02/58-revision-v1/', 0, 'revision', '', 0),
(65, 4, '2019-05-02 16:54:04', '2019-05-02 06:54:04', '', 'Events', '', 'inherit', 'closed', 'closed', '', '59-revision-v1', '', '', '2019-05-02 16:54:04', '2019-05-02 06:54:04', '', 59, 'http://localhost:8888/index.php/2019/05/02/59-revision-v1/', 0, 'revision', '', 0),
(66, 4, '2019-05-02 16:54:04', '2019-05-02 06:54:04', '', 'Services', '', 'inherit', 'closed', 'closed', '', '60-revision-v1', '', '', '2019-05-02 16:54:04', '2019-05-02 06:54:04', '', 60, 'http://localhost:8888/index.php/2019/05/02/60-revision-v1/', 0, 'revision', '', 0),
(67, 4, '2019-05-02 16:54:04', '2019-05-02 06:54:04', '', 'About Us', '', 'inherit', 'closed', 'closed', '', '61-revision-v1', '', '', '2019-05-02 16:54:04', '2019-05-02 06:54:04', '', 61, 'http://localhost:8888/index.php/2019/05/02/61-revision-v1/', 0, 'revision', '', 0),
(68, 4, '2019-05-02 16:54:04', '2019-05-02 06:54:04', '', 'Apply Now', '', 'inherit', 'closed', 'closed', '', '62-revision-v1', '', '', '2019-05-02 16:54:04', '2019-05-02 06:54:04', '', 62, 'http://localhost:8888/index.php/2019/05/02/62-revision-v1/', 0, 'revision', '', 0),
(69, 4, '2019-05-02 16:54:04', '2019-05-02 06:54:04', '', 'Shop', '', 'inherit', 'closed', 'closed', '', '63-revision-v1', '', '', '2019-05-02 16:54:04', '2019-05-02 06:54:04', '', 63, 'http://localhost:8888/index.php/2019/05/02/63-revision-v1/', 0, 'revision', '', 0),
(70, 4, '2019-05-02 16:54:04', '2019-05-02 06:54:04', ' ', '', '', 'publish', 'closed', 'closed', '', '70', '', '', '2019-05-02 16:54:04', '2019-05-02 06:54:04', '', 0, 'http://localhost:8888/index.php/2019/05/02/70/', 2, 'nav_menu_item', '', 0),
(71, 4, '2019-05-02 16:54:04', '2019-05-02 06:54:04', ' ', '', '', 'publish', 'closed', 'closed', '', '71', '', '', '2019-05-02 16:54:04', '2019-05-02 06:54:04', '', 0, 'http://localhost:8888/index.php/2019/05/02/71/', 3, 'nav_menu_item', '', 0),
(72, 4, '2019-05-02 16:54:04', '2019-05-02 06:54:04', ' ', '', '', 'publish', 'closed', 'closed', '', '72', '', '', '2019-05-02 16:54:04', '2019-05-02 06:54:04', '', 0, 'http://localhost:8888/index.php/2019/05/02/72/', 4, 'nav_menu_item', '', 0),
(73, 4, '2019-05-02 16:54:04', '2019-05-02 06:54:04', ' ', '', '', 'publish', 'closed', 'closed', '', '73', '', '', '2019-05-02 16:54:04', '2019-05-02 06:54:04', '', 0, 'http://localhost:8888/index.php/2019/05/02/73/', 6, 'nav_menu_item', '', 0),
(74, 4, '2019-05-02 16:54:04', '2019-05-02 06:54:04', ' ', '', '', 'publish', 'closed', 'closed', '', '74', '', '', '2019-05-02 16:54:04', '2019-05-02 06:54:04', '', 0, 'http://localhost:8888/index.php/2019/05/02/74/', 7, 'nav_menu_item', '', 0),
(75, 4, '2019-05-02 16:54:04', '2019-05-02 06:54:04', ' ', '', '', 'publish', 'closed', 'closed', '', '75', '', '', '2019-05-02 16:54:04', '2019-05-02 06:54:04', '', 0, 'http://localhost:8888/index.php/2019/05/02/75/', 5, 'nav_menu_item', '', 0),
(76, 4, '2019-05-02 17:40:50', '2019-05-02 07:40:50', '<!-- wp:gallery {"ids":["85","86","87"]} -->\n<ul class="wp-block-gallery columns-3 is-cropped"><li class="blocks-gallery-item"><figure><img src="http://localhost:8888/wp-content/uploads/2019/05/breakfast_lunches-1-724x1024.jpg" alt="" data-id="85" data-link="http://localhost:8888/index.php/homepage/breakfast_lunches-2/" class="wp-image-85"/><figcaption><br><br></figcaption></figure></li><li class="blocks-gallery-item"><figure><img src="http://localhost:8888/wp-content/uploads/2019/05/something_sweet-1-724x1024.jpg" alt="" data-id="86" data-link="http://localhost:8888/index.php/homepage/something_sweet-2/" class="wp-image-86"/></figure></li><li class="blocks-gallery-item"><figure><img src="http://localhost:8888/wp-content/uploads/2019/05/speciality_coffee-2-724x1024.jpg" alt="" data-id="87" data-link="http://localhost:8888/index.php/homepage/speciality_coffee-3/" class="wp-image-87"/></figure></li></ul>\n<!-- /wp:gallery -->\n\n<!-- wp:paragraph -->\n<p></p>\n<!-- /wp:paragraph -->', '', '', 'publish', 'closed', 'closed', '', 'homepage', '', '', '2019-05-02 17:53:07', '2019-05-02 07:53:07', '', 0, 'http://localhost:8888/?page_id=76', 0, 'page', '', 0),
(77, 4, '2019-05-02 17:40:50', '2019-05-02 07:40:50', '{"show_on_front":{"value":"page","type":"option","user_id":4,"date_modified_gmt":"2019-05-02 07:40:50"},"page_on_front":{"value":"76","type":"option","user_id":4,"date_modified_gmt":"2019-05-02 07:40:50"},"nav_menus_created_posts":{"value":[76],"type":"option","user_id":4,"date_modified_gmt":"2019-05-02 07:40:50"}}', '', '', 'trash', 'closed', 'closed', '', 'b8e2c100-23e8-467d-a0d5-d2daac71ffa4', '', '', '2019-05-02 17:40:50', '2019-05-02 07:40:50', '', 0, 'http://localhost:8888/index.php/2019/05/02/b8e2c100-23e8-467d-a0d5-d2daac71ffa4/', 0, 'customize_changeset', '', 0),
(78, 4, '2019-05-02 17:40:50', '2019-05-02 07:40:50', '', 'HomePage', '', 'inherit', 'closed', 'closed', '', '76-revision-v1', '', '', '2019-05-02 17:40:50', '2019-05-02 07:40:50', '', 76, 'http://localhost:8888/index.php/2019/05/02/76-revision-v1/', 0, 'revision', '', 0),
(79, 4, '2019-05-02 17:41:40', '2019-05-02 07:41:40', '', 'speciality_coffee', '', 'inherit', 'open', 'closed', '', 'speciality_coffee', '', '', '2019-05-02 17:55:17', '2019-05-02 07:55:17', '', 76, 'http://localhost:8888/wp-content/uploads/2019/05/speciality_coffee.jpg', 0, 'attachment', 'image/jpeg', 0),
(81, 4, '2019-05-02 17:43:39', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'open', 'open', '', '', '', '', '2019-05-02 17:43:39', '0000-00-00 00:00:00', '', 0, 'http://localhost:8888/?p=81', 0, 'post', '', 0),
(82, 4, '2019-05-02 17:43:51', '2019-05-02 07:43:51', '', 'speciality_coffee', '', 'inherit', 'open', 'closed', '', 'speciality_coffee-2', '', '', '2019-05-02 17:55:15', '2019-05-02 07:55:15', '', 81, 'http://localhost:8888/wp-content/uploads/2019/05/speciality_coffee-1.jpg', 0, 'attachment', 'image/jpeg', 0),
(83, 4, '2019-05-02 17:44:22', '2019-05-02 07:44:22', '', 'breakfast_lunches', '', 'inherit', 'open', 'closed', '', 'breakfast_lunches', '', '', '2019-05-02 17:55:13', '2019-05-02 07:55:13', '', 81, 'http://localhost:8888/wp-content/uploads/2019/05/breakfast_lunches.jpg', 0, 'attachment', 'image/jpeg', 0),
(84, 4, '2019-05-02 17:44:28', '2019-05-02 07:44:28', '', 'something_sweet', '', 'inherit', 'open', 'closed', '', 'something_sweet', '', '', '2019-05-02 17:55:11', '2019-05-02 07:55:11', '', 81, 'http://localhost:8888/wp-content/uploads/2019/05/something_sweet.jpg', 0, 'attachment', 'image/jpeg', 0),
(85, 4, '2019-05-02 17:45:11', '2019-05-02 07:45:11', '', 'breakfast_lunches', '', 'inherit', 'open', 'closed', '', 'breakfast_lunches-2', '', '', '2019-05-02 17:55:09', '2019-05-02 07:55:09', '', 76, 'http://localhost:8888/wp-content/uploads/2019/05/breakfast_lunches-1.jpg', 0, 'attachment', 'image/jpeg', 0),
(86, 4, '2019-05-02 17:45:11', '2019-05-02 07:45:11', '', 'something_sweet', '', 'inherit', 'open', 'closed', '', 'something_sweet-2', '', '', '2019-05-02 17:55:05', '2019-05-02 07:55:05', '', 76, 'http://localhost:8888/wp-content/uploads/2019/05/something_sweet-1.jpg', 0, 'attachment', 'image/jpeg', 0),
(87, 4, '2019-05-02 17:45:12', '2019-05-02 07:45:12', '', 'speciality_coffee', '', 'inherit', 'open', 'closed', '', 'speciality_coffee-3', '', '', '2019-05-02 17:55:03', '2019-05-02 07:55:03', '', 76, 'http://localhost:8888/wp-content/uploads/2019/05/speciality_coffee-2.jpg', 0, 'attachment', 'image/jpeg', 0),
(88, 4, '2019-05-02 17:45:14', '2019-05-02 07:45:14', '<!-- wp:gallery {"ids":[85,86,87]} -->\n<ul class="wp-block-gallery columns-3 is-cropped"><li class="blocks-gallery-item"><figure><img src="http://localhost:8888/wp-content/uploads/2019/05/breakfast_lunches-1-724x1024.jpg" alt="" data-id="85" data-link="http://localhost:8888/index.php/homepage/breakfast_lunches-2/" class="wp-image-85"/></figure></li><li class="blocks-gallery-item"><figure><img src="http://localhost:8888/wp-content/uploads/2019/05/something_sweet-1-724x1024.jpg" alt="" data-id="86" data-link="http://localhost:8888/index.php/homepage/something_sweet-2/" class="wp-image-86"/></figure></li><li class="blocks-gallery-item"><figure><img src="http://localhost:8888/wp-content/uploads/2019/05/speciality_coffee-2-724x1024.jpg" alt="" data-id="87" data-link="http://localhost:8888/index.php/homepage/speciality_coffee-3/" class="wp-image-87"/></figure></li></ul>\n<!-- /wp:gallery -->', '', '', 'inherit', 'closed', 'closed', '', '76-revision-v1', '', '', '2019-05-02 17:45:14', '2019-05-02 07:45:14', '', 76, 'http://localhost:8888/index.php/2019/05/02/76-revision-v1/', 0, 'revision', '', 0),
(89, 4, '2019-05-02 17:52:10', '2019-05-02 07:52:10', '<!-- wp:gallery {"ids":["85","86","87"]} -->\n<ul class="wp-block-gallery columns-3 is-cropped"><li class="blocks-gallery-item"><figure><img src="http://localhost:8888/wp-content/uploads/2019/05/breakfast_lunches-1-724x1024.jpg" alt="" data-id="85" data-link="http://localhost:8888/index.php/homepage/breakfast_lunches-2/" class="wp-image-85"/><figcaption><a href="http://localhost:8888/index.php/menu/">http://localhost:8888/index.php/menu/</a></figcaption></figure></li><li class="blocks-gallery-item"><figure><img src="http://localhost:8888/wp-content/uploads/2019/05/something_sweet-1-724x1024.jpg" alt="" data-id="86" data-link="http://localhost:8888/index.php/homepage/something_sweet-2/" class="wp-image-86"/></figure></li><li class="blocks-gallery-item"><figure><img src="http://localhost:8888/wp-content/uploads/2019/05/speciality_coffee-2-724x1024.jpg" alt="" data-id="87" data-link="http://localhost:8888/index.php/homepage/speciality_coffee-3/" class="wp-image-87"/></figure></li></ul>\n<!-- /wp:gallery -->\n\n<!-- wp:paragraph -->\n<p></p>\n<!-- /wp:paragraph -->', '', '', 'inherit', 'closed', 'closed', '', '76-revision-v1', '', '', '2019-05-02 17:52:10', '2019-05-02 07:52:10', '', 76, 'http://localhost:8888/index.php/2019/05/02/76-revision-v1/', 0, 'revision', '', 0),
(90, 4, '2019-05-02 17:52:52', '2019-05-02 07:52:52', '<!-- wp:gallery {"ids":["85","86","87"],"linkTo":"attachment"} -->\n<ul class="wp-block-gallery columns-3 is-cropped"><li class="blocks-gallery-item"><figure><a href="http://localhost:8888/index.php/homepage/breakfast_lunches-2/"><img src="http://localhost:8888/wp-content/uploads/2019/05/breakfast_lunches-1-724x1024.jpg" alt="" data-id="85" data-link="http://localhost:8888/index.php/homepage/breakfast_lunches-2/" class="wp-image-85"/></a><figcaption><br><br></figcaption></figure></li><li class="blocks-gallery-item"><figure><a href="http://localhost:8888/index.php/homepage/something_sweet-2/"><img src="http://localhost:8888/wp-content/uploads/2019/05/something_sweet-1-724x1024.jpg" alt="" data-id="86" data-link="http://localhost:8888/index.php/homepage/something_sweet-2/" class="wp-image-86"/></a></figure></li><li class="blocks-gallery-item"><figure><a href="http://localhost:8888/index.php/homepage/speciality_coffee-3/"><img src="http://localhost:8888/wp-content/uploads/2019/05/speciality_coffee-2-724x1024.jpg" alt="" data-id="87" data-link="http://localhost:8888/index.php/homepage/speciality_coffee-3/" class="wp-image-87"/></a></figure></li></ul>\n<!-- /wp:gallery -->\n\n<!-- wp:paragraph -->\n<p></p>\n<!-- /wp:paragraph -->', '', '', 'inherit', 'closed', 'closed', '', '76-revision-v1', '', '', '2019-05-02 17:52:52', '2019-05-02 07:52:52', '', 76, 'http://localhost:8888/index.php/2019/05/02/76-revision-v1/', 0, 'revision', '', 0),
(91, 4, '2019-05-02 17:53:07', '2019-05-02 07:53:07', '<!-- wp:gallery {"ids":["85","86","87"]} -->\n<ul class="wp-block-gallery columns-3 is-cropped"><li class="blocks-gallery-item"><figure><img src="http://localhost:8888/wp-content/uploads/2019/05/breakfast_lunches-1-724x1024.jpg" alt="" data-id="85" data-link="http://localhost:8888/index.php/homepage/breakfast_lunches-2/" class="wp-image-85"/><figcaption><br><br></figcaption></figure></li><li class="blocks-gallery-item"><figure><img src="http://localhost:8888/wp-content/uploads/2019/05/something_sweet-1-724x1024.jpg" alt="" data-id="86" data-link="http://localhost:8888/index.php/homepage/something_sweet-2/" class="wp-image-86"/></figure></li><li class="blocks-gallery-item"><figure><img src="http://localhost:8888/wp-content/uploads/2019/05/speciality_coffee-2-724x1024.jpg" alt="" data-id="87" data-link="http://localhost:8888/index.php/homepage/speciality_coffee-3/" class="wp-image-87"/></figure></li></ul>\n<!-- /wp:gallery -->\n\n<!-- wp:paragraph -->\n<p></p>\n<!-- /wp:paragraph -->', '', '', 'inherit', 'closed', 'closed', '', '76-revision-v1', '', '', '2019-05-02 17:53:07', '2019-05-02 07:53:07', '', 76, 'http://localhost:8888/index.php/2019/05/02/76-revision-v1/', 0, 'revision', '', 0),
(92, 4, '2019-05-02 18:00:27', '2019-05-02 08:00:27', '{"sidebars_widgets[sidebar-1]":{"value":[],"type":"option","user_id":4,"date_modified_gmt":"2019-05-02 08:00:27"}}', '', '', 'trash', 'closed', 'closed', '', '2451bed6-ca99-4061-8086-7b915494ced7', '', '', '2019-05-02 18:00:27', '2019-05-02 08:00:27', '', 0, 'http://localhost:8888/index.php/2019/05/02/2451bed6-ca99-4061-8086-7b915494ced7/', 0, 'customize_changeset', '', 0) ;

#
# End of data contents of table `wp_posts`
# --------------------------------------------------------



#
# Delete any existing table `wp_term_relationships`
#

DROP TABLE IF EXISTS `wp_term_relationships`;


#
# Table structure of table `wp_term_relationships`
#

CREATE TABLE `wp_term_relationships` (
  `object_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_taxonomy_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_order` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  KEY `term_taxonomy_id` (`term_taxonomy_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_term_relationships`
#
INSERT INTO `wp_term_relationships` ( `object_id`, `term_taxonomy_id`, `term_order`) VALUES
(1, 1, 0),
(5, 1, 0),
(12, 1, 0),
(20, 1, 0),
(38, 2, 0),
(70, 2, 0),
(71, 2, 0),
(72, 2, 0),
(73, 2, 0),
(74, 2, 0),
(75, 2, 0) ;

#
# End of data contents of table `wp_term_relationships`
# --------------------------------------------------------



#
# Delete any existing table `wp_term_taxonomy`
#

DROP TABLE IF EXISTS `wp_term_taxonomy`;


#
# Table structure of table `wp_term_taxonomy`
#

CREATE TABLE `wp_term_taxonomy` (
  `term_taxonomy_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `taxonomy` varchar(32) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `description` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_taxonomy_id`),
  UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  KEY `taxonomy` (`taxonomy`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_term_taxonomy`
#
INSERT INTO `wp_term_taxonomy` ( `term_taxonomy_id`, `term_id`, `taxonomy`, `description`, `parent`, `count`) VALUES
(1, 1, 'category', '', 0, 3),
(2, 2, 'nav_menu', '', 0, 7) ;

#
# End of data contents of table `wp_term_taxonomy`
# --------------------------------------------------------



#
# Delete any existing table `wp_termmeta`
#

DROP TABLE IF EXISTS `wp_termmeta`;


#
# Table structure of table `wp_termmeta`
#

CREATE TABLE `wp_termmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`meta_id`),
  KEY `term_id` (`term_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_termmeta`
#

#
# End of data contents of table `wp_termmeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_terms`
#

DROP TABLE IF EXISTS `wp_terms`;


#
# Table structure of table `wp_terms`
#

CREATE TABLE `wp_terms` (
  `term_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `slug` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `term_group` bigint(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_id`),
  KEY `slug` (`slug`(191)),
  KEY `name` (`name`(191))
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_terms`
#
INSERT INTO `wp_terms` ( `term_id`, `name`, `slug`, `term_group`) VALUES
(1, 'Uncategorized', 'uncategorized', 0),
(2, 'Header-Nav', 'header-nav', 0) ;

#
# End of data contents of table `wp_terms`
# --------------------------------------------------------



#
# Delete any existing table `wp_usermeta`
#

DROP TABLE IF EXISTS `wp_usermeta`;


#
# Table structure of table `wp_usermeta`
#

CREATE TABLE `wp_usermeta` (
  `umeta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`umeta_id`),
  KEY `user_id` (`user_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=77 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_usermeta`
#
INSERT INTO `wp_usermeta` ( `umeta_id`, `user_id`, `meta_key`, `meta_value`) VALUES
(1, 1, 'nickname', 'brodiet'),
(2, 1, 'first_name', ''),
(3, 1, 'last_name', ''),
(4, 1, 'description', ''),
(5, 1, 'rich_editing', 'true'),
(6, 1, 'syntax_highlighting', 'true'),
(7, 1, 'comment_shortcuts', 'false'),
(8, 1, 'admin_color', 'fresh'),
(9, 1, 'use_ssl', '0'),
(10, 1, 'show_admin_bar_front', 'true'),
(11, 1, 'locale', 'en_AU'),
(12, 1, 'wp_capabilities', 'a:1:{s:13:"administrator";b:1;}'),
(13, 1, 'wp_user_level', '10'),
(14, 1, 'dismissed_wp_pointers', 'wp496_privacy'),
(15, 1, 'show_welcome_panel', '1'),
(16, 1, 'session_tokens', 'a:4:{s:64:"c3bca0e81d32beee65dfb2ed3be373741e47519647065d0157851a41fb610885";a:4:{s:10:"expiration";i:1557101834;s:2:"ip";s:13:"138.130.17.95";s:2:"ua";s:115:"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36";s:5:"login";i:1555892234;}s:64:"902d0fb0cc6b30835719f9362cb08950b5d5abc30c602355ba1be64d807d9849";a:4:{s:10:"expiration";i:1557102054;s:2:"ip";s:13:"138.130.17.95";s:2:"ua";s:115:"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36";s:5:"login";i:1555892454;}s:64:"2030d072979703b30e46db36e34f21a7bb200698ce559bb62d8f983d58e2cb37";a:4:{s:10:"expiration";i:1557102062;s:2:"ip";s:13:"138.130.17.95";s:2:"ua";s:115:"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36";s:5:"login";i:1555892462;}s:64:"1b8cc9f635ff114be2deb6ea185b17342d335d7f363ee4ef15799b837acc7ea7";a:4:{s:10:"expiration";i:1557102981;s:2:"ip";s:13:"138.130.17.95";s:2:"ua";s:115:"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36";s:5:"login";i:1555893381;}}'),
(17, 1, 'wp_dashboard_quick_press_last_post_id', '4'),
(18, 1, 'community-events-location', 'a:1:{s:2:"ip";s:12:"138.130.30.0";}'),
(37, 3, 'nickname', 'dummy-account'),
(38, 3, 'first_name', ''),
(39, 3, 'last_name', ''),
(40, 3, 'description', ''),
(41, 3, 'rich_editing', 'true'),
(42, 3, 'syntax_highlighting', 'true'),
(43, 3, 'comment_shortcuts', 'false'),
(44, 3, 'admin_color', 'fresh'),
(45, 3, 'use_ssl', '0'),
(46, 3, 'show_admin_bar_front', 'true'),
(47, 3, 'locale', ''),
(48, 3, 'wp_capabilities', 'a:1:{s:13:"administrator";b:1;}'),
(49, 3, 'wp_user_level', '10'),
(50, 3, 'dismissed_wp_pointers', 'wp496_privacy,theme_editor_notice'),
(51, 3, 'session_tokens', 'a:4:{s:64:"1a55066b44a88a082dd030a3e2dc0c9720b48fb559be2621b74916b0a3cb2f81";a:4:{s:10:"expiration";i:1556066596;s:2:"ip";s:13:"138.130.17.95";s:2:"ua";s:115:"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36";s:5:"login";i:1555893796;}s:64:"835a5deaed32e8a372a590fdeeb170cba1a6edc07dcdefa922e442eea927dc53";a:4:{s:10:"expiration";i:1556159443;s:2:"ip";s:14:"138.130.30.250";s:2:"ua";s:115:"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36";s:5:"login";i:1555986643;}s:64:"e72efc9ba2e84ec3cd9d19bf2164fddb49bddc0ec0177c2ce2b70dd9b68764b3";a:4:{s:10:"expiration";i:1556167833;s:2:"ip";s:14:"101.175.99.187";s:2:"ua";s:115:"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36";s:5:"login";i:1555995033;}s:64:"e7a54bc42a607836079493f1e9b7b9ba46915846da3c707ffd06a6c5a3c84e77";a:4:{s:10:"expiration";i:1556168676;s:2:"ip";s:3:"::1";s:2:"ua";s:115:"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36";s:5:"login";i:1555995876;}}'),
(52, 3, 'wp_dashboard_quick_press_last_post_id', '7'),
(53, 3, 'community-events-location', 'a:1:{s:2:"ip";s:12:"101.175.99.0";}'),
(54, 1, 'wp_user-settings', 'libraryContent=browse'),
(55, 1, 'wp_user-settings-time', '1555977477'),
(56, 4, 'nickname', 'hn'),
(57, 4, 'first_name', 'Hendrik'),
(58, 4, 'last_name', 'Nel'),
(59, 4, 'description', ''),
(60, 4, 'rich_editing', 'true'),
(61, 4, 'syntax_highlighting', 'true'),
(62, 4, 'comment_shortcuts', 'false'),
(63, 4, 'admin_color', 'fresh'),
(64, 4, 'use_ssl', '0'),
(65, 4, 'show_admin_bar_front', 'true'),
(66, 4, 'locale', ''),
(67, 4, 'wp_capabilities', 'a:1:{s:13:"administrator";b:1;}'),
(68, 4, 'wp_user_level', '10'),
(69, 4, 'dismissed_wp_pointers', 'wp496_privacy'),
(71, 4, 'wp_dashboard_quick_press_last_post_id', '22'),
(72, 4, 'managenav-menuscolumnshidden', 'a:5:{i:0;s:11:"link-target";i:1;s:11:"css-classes";i:2;s:3:"xfn";i:3;s:11:"description";i:4;s:15:"title-attribute";}'),
(73, 4, 'metaboxhidden_nav-menus', 'a:1:{i:0;s:12:"add-post_tag";}'),
(74, 4, 'wp_user-settings', 'libraryContent=browse'),
(75, 4, 'wp_user-settings-time', '1556597158'),
(76, 4, 'session_tokens', 'a:1:{s:64:"15e0bfb214dfe6dc90e7ce52d46f8aedc97bdf6cd29a6c47fcc1762860bc9787";a:4:{s:10:"expiration";i:1557026620;s:2:"ip";s:3:"::1";s:2:"ua";s:115:"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36";s:5:"login";i:1556853820;}}') ;

#
# End of data contents of table `wp_usermeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_users`
#

DROP TABLE IF EXISTS `wp_users`;


#
# Table structure of table `wp_users`
#

CREATE TABLE `wp_users` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_login` varchar(60) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_pass` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_nicename` varchar(50) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_email` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_url` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_activation_key` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_status` int(11) NOT NULL DEFAULT '0',
  `display_name` varchar(250) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`ID`),
  KEY `user_login_key` (`user_login`),
  KEY `user_nicename` (`user_nicename`),
  KEY `user_email` (`user_email`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_users`
#
INSERT INTO `wp_users` ( `ID`, `user_login`, `user_pass`, `user_nicename`, `user_email`, `user_url`, `user_registered`, `user_activation_key`, `user_status`, `display_name`) VALUES
(1, 'admin', '$P$BV1ktU8QF69Tai07k7a55b8Ko6VuPn1', 'admin', 'jc313927@gmail.com', '', '2019-04-22 00:07:38', '1555891710:$P$BszW6i4cxd.3tcm2mjEdO1Ji4YFjW41', 0, 'brodiet'),
(3, 'dummy-account', '$P$Blf1L0KMsv7rM2GP4GcLlmCLY3yNJH0', 'dummy-account', 'dummy-account@team2.coffeecan.com', '', '2019-04-22 00:43:03', '', 0, 'dummy-account'),
(4, 'hn', '$P$BJhecbMBHsEvxFVuGHJW6ShSABIYjY/', 'hn', 'hendrik.nel@my.jcu.edu.au', '', '2019-04-23 05:05:17', '', 0, 'Hendrik Nel') ;

#
# End of data contents of table `wp_users`
# --------------------------------------------------------

#
# Add constraints back in and apply any alter data queries.
#

